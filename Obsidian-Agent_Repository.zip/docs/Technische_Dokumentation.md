# Obsidian-Agent

Lokale GUI (im Browser, nur auf deinem PC: `http://127.0.0.1:5055`) zur Verwaltung deines Obsidian-Vaults
mit SQLite-Planer und täglicher Aktualisierung um 04:00.

**Grundprinzip:** Die Markdown-Dateien im Vault sind die einzige Wahrheit. Die SQLite-Datenbank (`planer.db`)
ist Index und Planer: Sie wird bei jedem Sync aus dem Vault neu aufgebaut. Du kannst also jederzeit direkt in
Obsidian arbeiten. Der Agent liest beim nächsten Sync alles wieder ein und es geht nichts verloren.

## Installation – Windows

1. Python 3.10+ von python.org installieren (Häkchen „Add python.exe to PATH“).
2. Ordner `obsidian-agent` z.B. nach `C:\Group\obsidian-agent` entpacken (**nicht** in den Vault).
3. **`installieren.bat`** doppelklicken. Das Skript braucht keine Adminrechte und
   - richtet die Python-Umgebung ein,
   - fragt per Ordner-Dialog nach deinem Vault,
   - legt die Aufgabe **„Obsidian-Agent Weboberflaeche“** an. Sie startet die GUI bei jeder Anmeldung
     **im Hintergrund**, ohne Fenster, ohne Zeitlimit und auch im Akkubetrieb,
   - legt die Aufgabe **„Obsidian-Agent Tages-Sync“** an. Sie läuft täglich um 04:00, und war der PC aus, wird der Lauf nachgeholt,
   - startet den Agent und öffnet den Browser.
4. Danach einfach `http://127.0.0.1:5055` aufrufen (Lesezeichen) oder `start.bat` doppelklicken.

Beenden oder neu starten: `schtasks /End` bzw. `/Run /TN "Obsidian-Agent Weboberflaeche"`.
Protokoll: `%LOCALAPPDATA%\obsidian-agent\gui.log`.
Nach einer Änderung von Sync-Zeit oder Port `installieren.bat` einfach nochmals ausführen.

## Installation – macOS (Notebook)

1. Ordner `obsidian-agent` z.B. nach `~/Programme/obsidian-agent` entpacken (**nicht** in den Vault).
2. Im Ordner `mac/` die Datei **`installieren_mac.command`** doppelklicken.
   Meldet macOS „nicht verifizierter Entwickler“: Rechtsklick → *Öffnen* → *Öffnen*.
3. Das Skript
   - prüft Python (mind. 3.9; fehlt es, öffnet sich python.org, alternativ `brew install python`),
   - richtet die Python-Umgebung ein,
   - fragt per Ordner-Dialog nach deinem Vault,
   - richtet den **täglichen Sync per launchd** ein. Er läuft auch, wenn die GUI nicht offen ist,
     und ist der Mac um 04:00 im Ruhezustand, holt macOS den Lauf beim Aufwachen nach,
   - fragt, ob der Agent bei jeder Anmeldung automatisch im Hintergrund starten soll.
4. Starten danach mit **`mac/starten_mac.command`**. Läuft der Agent schon im Hintergrund, öffnet sich nur der Browser.

**Hinweis zu den Ordnerrechten:** Liegt der Vault in *Dokumente*, auf dem *Schreibtisch* oder in *iCloud Drive*
(dort speichert Obsidian auf dem Mac standardmässig), kann macOS den Hintergrund-Sync blockieren.
Der Installer prüft das und zeigt dir, welche Datei du unter
*Systemeinstellungen → Datenschutz & Sicherheit → Festplattenvollzugriff* hinzufügen musst.
Protokolle liegen unter `~/Library/Logs/obsidian-agent/`.

Wird die Sync-Zeit in den Einstellungen geändert, `installieren_mac.command` einfach nochmals ausführen.
Dabei wird nichts überschrieben.

## Installation – Linux
`./start.sh` startet die GUI. Für den täglichen Sync in `crontab -e`:
`0 4 * * * cd /pfad/obsidian-agent && .venv/bin/python agent.py sync --geplant`

## Deinstallation & Umzug

| | Windows | macOS |
|---|---|---|
| Skript | `deinstallieren.bat` | `mac/deinstallieren_mac.command` |

Das Skript
1. beendet den laufenden Agent,
2. entfernt die geplanten Aufgaben und den Autostart (Windows-Aufgabenplanung bzw. launchd),
3. **sichert `config.json` und `planer.db`** in den Ordner `obsidian-agent-backup_<Datum>` auf dem Desktop,
4. löscht die Python-Umgebung (`.venv`) und auf Wunsch den ganzen Programmordner.

**Dein Obsidian-Vault wird nie verändert oder gelöscht.**

**Programm umziehen** (anderer Ordner, anderer PC oder Windows → Mac):
1. Am alten Ort das Deinstallations-Skript ausführen.
2. Programm am neuen Ort aus dem ZIP entpacken.
3. `config.json` und `planer.db` aus dem Backup in den neuen Programmordner kopieren.
4. Installieren: Windows mit `installieren.bat`, Mac mit `mac/installieren_mac.command`.
5. Hat sich der Vault-Pfad geändert (z.B. von `C:\…` zu `/Users/…`), fragt der Mac-Installer automatisch nach dem Vault.
   Unter Windows trägst du den Pfad in den Einstellungen ein.

Warum deinstallieren statt den Ordner einfach zu verschieben? Die Python-Umgebung `.venv` enthält feste Pfade,
und die geplante Aufgabe zeigt auf den alten Ort. Beides wird beim Neuinstallieren korrekt neu angelegt.
Die `planer.db` ist optional: Sie wird aus dem Vault komplett neu aufgebaut. Nur die Tageshistorie geht ohne sie verloren.

**Nur den Vault verschieben?** Kein Umzug nötig: einfach in den Einstellungen den neuen Vault-Pfad eintragen.

## Funktionen

| Bereich | Was es macht | Ablage im Vault |
|---|---|---|
| **Heute** | Heutige Tasks oben, dann Überfällige, Demnächst und LCM-Warnungen. Neue Tasks direkt anlegen. | – |
| **Tasks** | Alle Tasks nach Gruppen. Mit einem Klick erledigt, Status ändern, „+1 Tag“ verschieben, Filter nach Projekt. Beim Anlegen mit Projekt wählst du den **Ordner im Projekt**. Die Liste wird live aus dem Vault gelesen, auch von Hand angelegte Ordner. Den vorgewählten Ordner legst du unter *Einstellungen → Standard-Ordner für Tasks* fest. | `Tasks/` oder `Projekte/<Name>/<Ordner>/` |
| **Projekte** | Neues Projekt mit fixer Struktur `01_…` bis `10_…` (inkl. **`07_DevOps`** mit ausführlicher DevOps-Readme), je Unterordner `readme_<Ordnername>.md` und eine Übersichtsnotiz. Mit **„Alle Projekte ergänzen“** bekommen bestehende Projekte fehlende Standardordner. Es wird nichts überschrieben. | `Projekte/<Name>/01_… bis 10_…` |
| **Ordner** | Eigene Ordner überall im Vault anlegen (optional mit `readme_<Name>.md`). Ausserdem lässt sich die Projekt-Standardstruktur um eigene Ordner erweitern, für neue und auf Wunsch auch für alle bestehenden Projekte. | frei wählbar |
| **Dokumentation** | Notizen aus Vorlagen: Meeting, Entscheidung (ADR), Runbook, Change, Störung, Kontakt, Report. Sie landen automatisch im passenden Projekt-Unterordner. | z.B. Meeting → `10_Korrespondenz` |
| **Aus Vorlage** | Neue Markdown-Datei aus **jeder** Vorlage in `_Vorlagen/` (auch eigenen) direkt in ein Projekt und einen frei wählbaren Ordner im Projekt anlegen. Der passende Ordner ist vorgewählt, bei eigenen Vorlagen über `zielordner:` im Frontmatter. | frei wählbar |
| **Wiki** | Artikel nach Kategorien, Suche im Wiki. Die Kategorien sind die Unterordner des Wiki-Ordners (auch leere und Unterkategorien wie `Netzwerk/Firewall`). Beim Anlegen wählst du eine Kategorie aus der Liste oder legst eine neue an. `_Index.md` wird automatisch gepflegt. | `Wiki/<Kategorie>/` |
| **LifeCycle** | Hardware, Software, Lizenzen, Zertifikate und Verträge mit EOS/EOL und Ampel (rot / orange / gelb / grün). | `LifeCycle/<Kategorie>/LCM_*.md` |
| **DevOps** | Pipelines, Deployments, Umgebungen, Skripte, Repositories, Monitoring und Infrastruktur, mit Umgebung (Dev/Test/Staging/Prod), Repository-Link und Status, den du direkt in der Tabelle änderst. | `DevOps/<Kategorie>/` |
| **Ideenbox** | Ideen erfassen (Nutzen/Aufwand, eingereicht von) und als Board nach Status sortiert (Neu → In Prüfung → Angenommen → Umgesetzt / Abgelehnt). Mit „→ Task“ wird aus einer Idee ein Task, beide sind verlinkt. | `Ideenbox/Idee_<Datum>_<Titel>.md` |
| **Jour Fixe** | Serien von Jour Fixes (z.B. „Team Infrastruktur“) mit nächstem Termin, Turnus und Sitzungsnotizen. Jede neue Sitzungsnotiz enthält automatisch die offenen Pendenzen der Serie. Pendenzen sind normale Tasks mit dem Feld `jourfixe` und erscheinen auch unter Heute, Tasks und bei den Teammitgliedern. | `JourFixe/<Serie>/JF_<Datum>_<Serie>.md`, Pendenzen in `JourFixe/<Serie>/Pendenzen/` |
| **Teammitglieder** | Personenkarten mit Rolle, Kontakt, Skills und Vertretung sowie den offenen und überfälligen Tasks jeder Person. Die Zuordnung läuft über das Feld `verantwortlich` (Name oder Kürzel). | `Team/<Name>.md` |
| **Suche** | Volltextsuche über den ganzen Vault. | – |

Jeder Titel in der GUI ist ein `obsidian://`-Link und öffnet die Notiz direkt in Obsidian.

### Tägliche Übersicht (04:00)
- Liest alle `Task_*.md` im ganzen Vault ein (auch solche, die du in Obsidian von Hand anlegst).
- Schreibt die Tabelle `tagesuebersicht` in SQLite (Snapshot pro Tag: heute / überfällig / geplant / erledigt).
- Erzeugt `Planer/Heute.md` und ein Archiv `Planer/Archiv/Tagesuebersicht_JJJJ-MM-TT.md`, damit du die
  Übersicht auch in Obsidian (und auf dem Handy) siehst.

## Task-Format

```markdown
---
typ: task
titel: Firewall-Update vorbereiten
projekt: Kunde Muster AG
start: 2026-11-18        # auch 18.11.2026 geht
ende: 2026-11-20
status: offen            # offen | in_arbeit | wartend | erledigt
prioritaet: hoch         # hoch | mittel | niedrig
verantwortlich: Max
---
- [ ] Schritt 1
- [x] Schritt 2
```

Regeln:
- **Heute** = `start ≤ heute ≤ ende` · **Überfällig** = `ende < heute` · **Geplant** = `start > heute`
- Fehlt `status`, gilt ein Task als erledigt, wenn alle Checkboxen abgehakt sind.
- Der Fortschritt (z.B. 1/2) wird aus den Checkboxen berechnet.

## Vorlagen anpassen
Alle Vorlagen liegen in `_Vorlagen/` im Vault. Ändere sie in Obsidian, der Agent nutzt danach deine Version.
Die Platzhalter `{{title}}` und `{{date}}` funktionieren auch mit dem Obsidian-Kern-Plugin „Vorlagen“.
Gelöschte Vorlagen werden beim nächsten Sync wieder angelegt.

## Kommandozeile
```
python agent.py sync          # jetzt einlesen
python agent.py heute         # heutige Tasks in der Konsole
python agent.py projekt "Name"
```

## Konfiguration
`config.json` (wird beim ersten Start erzeugt, auch über die GUI unter Einstellungen änderbar):
Vault-Pfad, Ordnernamen, eigene Standard-Projektordner (`eigene_projekt_ordner`), Sync-Zeit, Warnschwelle für LCM, Port, DB-Pfad.

## Ohne Datenbank?
Für reines Anzeigen ginge es auch ohne SQLite, nämlich mit dem Community-Plugin **Dataview** (eine Beispielabfrage
steht in jeder `_Projekt_*.md`). Die Datenbank bringt aber drei Dinge, die Dataview nicht kann: einen Tages-Snapshot
(Historie, wer wann was erledigt hat), die GUI ausserhalb von Obsidian und die automatische Übersicht um 04:00
auch dann, wenn Obsidian geschlossen ist.
