"""
Obsidian-Agent – GUI (lokale Weboberfläche)
Start:  python app.py   ->  http://127.0.0.1:5055
"""
from __future__ import annotations

import datetime as dt
import os
import threading
import webbrowser

import urllib.parse

from flask import Flask, Response, flash, jsonify, redirect, render_template, request, url_for

import agent as core

app = Flask(__name__)
app.secret_key = "obsidian-agent-lokal"
AGENT = core.Agent()


@app.template_filter("dmy")
def _dmy(v):
    return core.dmy(v)


@app.context_processor
def _globals():
    return {"heute": dt.date.today(), "cfg": AGENT.cfg, "vault_ok": AGENT.vault_ok(),
            "letzter_sync": AGENT.letzter_sync(), "VERSION": core.VERSION, "PRIO": ["hoch", "mittel", "niedrig"],
            "TEAM_NAMEN": [p["titel"] for p in AGENT.eintraege("person")] if AGENT.vault_ok() else []}


@app.before_request
def _vault_pruefen():
    if request.endpoint in ("einstellungen", "static") or AGENT.vault_ok():
        return None
    flash(f"Vault-Ordner nicht gefunden: {AGENT.vault} – bitte in den Einstellungen setzen.", "fehler")
    return redirect(url_for("einstellungen"))


def _ok(msg):
    flash(msg, "ok")


def _fehler(exc):
    flash(str(exc), "fehler")


# --- Dashboard ---------------------------------------------------------------
@app.route("/")
def dashboard():
    g = AGENT.tasks()
    n = int(AGENT.cfg.get("demnaechst_tage", 7))
    grenze = dt.date.today() + dt.timedelta(days=n)
    bald = [t for t in g["geplant"] if core.parse_date(t["start"]) <= grenze]
    lcm = [e for e in AGENT.lcm_eintraege() if e["ampel"]["farbe"] in ("rot", "orange")]
    return render_template("dashboard.html", g=g, bald=bald, lcm=lcm,
                           notizen=AGENT.letzte_notizen(8), projekte=AGENT.projekte())


@app.post("/sync")
def sync():
    try:
        s = AGENT.sync("manuell")
        _ok(f"Aktualisiert: {s['dateien']} Dateien gelesen, {s['tasks_heute']} Tasks heute, "
            f"{s['tasks_offen']} offen ({s['dauer_ms']} ms).")
    except Exception as exc:
        _fehler(exc)
    return redirect(request.referrer or url_for("dashboard"))


# --- Tasks ---------------------------------------------------------------------
@app.route("/tasks")
def tasks():
    projekt = request.args.get("projekt", "")
    return render_template("tasks.html", g=AGENT.tasks(projekt=projekt), projekt=projekt,
                           projekte=AGENT.projekte(), status_liste=core.TASK_STATUS)


@app.post("/tasks/neu")
def task_neu():
    f = request.form
    try:
        p = AGENT.task_anlegen(f["titel"], f.get("start", ""), f.get("ende", ""), f.get("projekt", ""),
                               f.get("prioritaet", "mittel"), f.get("verantwortlich", ""),
                               f.get("beschreibung", ""), f.get("checkliste", ""),
                               unterordner=f.get("unterordner", ""))
        _ok(f"Task angelegt: {AGENT.rel(p)}")
    except Exception as exc:
        _fehler(exc)
    return redirect(request.referrer or url_for("tasks"))


@app.get("/api/projektordner")
def projekt_ordner_api():
    """Unterordner eines Projekts für die Ordnerauswahl im Task-Formular (live aus dem Vault)."""
    projekt = request.args.get("projekt", "")
    return jsonify({"ordner": AGENT.projekt_unterordner(projekt),
                    "standard": (AGENT.cfg.get("task_standard_ordner") or "").strip("/")})


@app.post("/tasks/status")
def task_status():
    try:
        AGENT.task_status_setzen(request.form["pfad"], request.form["status"])
    except Exception as exc:
        _fehler(exc)
    return redirect(request.referrer or url_for("tasks"))


@app.post("/tasks/verschieben")
def task_verschieben():
    try:
        AGENT.task_verschieben(request.form["pfad"], int(request.form.get("tage", 1)))
    except Exception as exc:
        _fehler(exc)
    return redirect(request.referrer or url_for("tasks"))


# --- Projekte ------------------------------------------------------------------
@app.route("/projekte")
def projekte():
    return render_template("projekte.html", projekte=AGENT.projekte(), struktur=AGENT.projekt_struktur(),
                           standard=list(core.PROJEKT_STRUKTUR))


@app.post("/projekte/neu")
def projekt_neu():
    f = request.form
    try:
        p = AGENT.projekt_anlegen(f["name"], f.get("kunde", ""), f.get("beschreibung", ""))
        _ok(f"Projekt angelegt bzw. ergänzt: {AGENT.rel(p)} "
            f"({len(AGENT.projekt_struktur())} Unterordner mit readme-Dateien)")
    except Exception as exc:
        _fehler(exc)
    return redirect(url_for("projekte"))


# --- Eigene Ordner ----------------------------------------------------------------
@app.route("/ordner")
def ordner():
    return render_template("ordner.html", ordner=AGENT.ordner_liste(), eltern=request.args.get("eltern", ""),
                           standard=core.PROJEKT_STRUKTUR,
                           eigene=AGENT.cfg.get("eigene_projekt_ordner") or {})


@app.post("/ordner/neu")
def ordner_neu():
    f = request.form
    try:
        d = AGENT.ordner_anlegen(f.get("eltern", ""), f["name"], f.get("zweck", ""), bool(f.get("readme")))
        _ok(f"Ordner angelegt: {AGENT.rel(d)}")
    except Exception as exc:
        _fehler(exc)
    return redirect(url_for("ordner", eltern=f.get("eltern", "")))


@app.post("/ordner/struktur")
def struktur_neu():
    f = request.form
    try:
        n = AGENT.struktur_ordner_hinzufuegen(f["name"], f.get("zweck", ""), bool(f.get("bestehende")))
        _ok("Ordner zur Projekt-Standardstruktur hinzugefügt"
            + (f" und in {n} bestehenden Projekten angelegt." if f.get("bestehende") else "."))
    except Exception as exc:
        _fehler(exc)
    return redirect(url_for("ordner"))


@app.post("/ordner/struktur/entfernen")
def struktur_entfernen():
    try:
        AGENT.struktur_ordner_entfernen(request.form["name"])
        _ok("Aus der Standardstruktur entfernt. Bestehende Ordner im Vault bleiben erhalten.")
    except Exception as exc:
        _fehler(exc)
    return redirect(url_for("ordner"))


@app.post("/projekte/ergaenzen")
def projekte_ergaenzen():
    try:
        n_proj, n_ord = AGENT.projekte_ergaenzen()
        _ok(f"{n_proj} Projekte ergänzt, {n_ord} Ordner neu angelegt. Bestehende Dateien wurden nicht verändert.")
    except Exception as exc:
        _fehler(exc)
    return redirect(url_for("projekte"))


# --- Projektprotokoll ----------------------------------------------------------------
@app.route("/protokoll")
def protokoll():
    projekt = request.args.get("projekt", "")
    return render_template("protokoll.html", projekt=projekt, protokolle=AGENT.protokolle(projekt),
                           projekte=AGENT.projekte(), status_liste=core.PROTOKOLL_STATUS,
                           neu=request.args.get("neu", ""), mail=request.args.get("mail", ""))


def _zeilen(prefix):
    f = request.form
    return list(zip(f.getlist(prefix + "_text"), f.getlist(prefix + "_wer"), f.getlist(prefix + "_bis")))


@app.post("/protokoll/neu")
def protokoll_neu():
    f = request.form
    try:
        aufgaben = _zeilen("aufgabe")
        p = AGENT.protokoll_anlegen(f.to_dict(), _zeilen("beschluss"), aufgaben)
        rel = AGENT.rel(p)
        n = sum(1 for a in aufgaben if (a[0] or "").strip())
        _ok(f"Protokoll gespeichert: {rel}" + (f" · {n} Aufgabe(n) als Task angelegt" if n else ""))
        return redirect(url_for("protokoll", projekt=f.get("projekt", ""), neu=rel, mail=f.get("danach", "")))
    except Exception as exc:
        _fehler(exc)
    return redirect(request.referrer or url_for("protokoll"))


@app.get("/protokoll/outlook")
def protokoll_outlook():
    """E-Mail-Entwurf (.eml) – öffnet sich in Outlook als neue Nachricht mit formatiertem Protokoll."""
    name, daten = AGENT.protokoll_eml(request.args["pfad"])
    try:
        AGENT.feld_setzen(request.args["pfad"], "status", "versendet") if request.args.get("markieren") else None
    except Exception:
        pass
    return Response(daten, mimetype="message/rfc822",
                    headers={"Content-Disposition": f"attachment; filename*=UTF-8''{urllib.parse.quote(name)}"})


@app.get("/protokoll/mailto")
def protokoll_mailto():
    """Einfache Text-Mail über das Standard-Mailprogramm (ohne Formatierung)."""
    m = AGENT.protokoll_mail(request.args["pfad"])
    q = urllib.parse.urlencode({"subject": m["betreff"], "body": m["text"]}, quote_via=urllib.parse.quote)
    return redirect(f"mailto:{','.join(m['an'])}?{q}")


@app.get("/protokoll/vorschau")
def protokoll_vorschau():
    m = AGENT.protokoll_mail(request.args["pfad"])
    return render_template("protokoll_vorschau.html", m=m, pfad=request.args["pfad"],
                           link=AGENT.obsidian_link(request.args["pfad"]))


# --- Projektaufgaben (Projektplan) ---------------------------------------------------
@app.route("/projektplan")
def projektplan():
    projekt = request.args.get("projekt", "")
    pfad = request.args.get("pfad", "")
    plan = None
    if pfad:
        try:
            AGENT.plan_abgleichen(pfad)
            plan = AGENT.plan_lesen(pfad)
        except Exception as exc:
            _fehler(exc)
    return render_template("projektplan.html", projekt=projekt, plaene=AGENT.plaene(projekt), plan=plan,
                           projekte=AGENT.projekte(), status_liste=core.TASK_STATUS,
                           status_text=AGENT.STATUS_TEXT)


@app.post("/projektplan/neu")
def projektplan_neu():
    f = request.form
    namen = f.getlist("phase_name")
    phasen = [{"name": n, "aufgaben": []} for n in namen]
    for nr, text, wer, frist, prio, unter in zip(f.getlist("aufgabe_phase"), f.getlist("aufgabe_text"),
                                                 f.getlist("aufgabe_wer"), f.getlist("aufgabe_bis"),
                                                 f.getlist("aufgabe_prio"), f.getlist("aufgabe_unter")):
        if nr.isdigit() and int(nr) < len(phasen):
            phasen[int(nr)]["aufgaben"].append((text, wer, frist, prio, unter))
    try:
        p = AGENT.plan_anlegen(f.to_dict(), phasen)
        n = sum(1 for ph in phasen for a in ph["aufgaben"] if a[0].strip())
        _ok(f"Projektplan angelegt: {AGENT.rel(p)} · {n} Aufgabe(n) als Task angelegt")
        return redirect(url_for("projektplan", pfad=AGENT.rel(p)))
    except Exception as exc:
        _fehler(exc)
    return redirect(request.referrer or url_for("projektplan"))


@app.post("/projektplan/aufgabe")
def projektplan_aufgabe():
    f = request.form
    try:
        t = AGENT.plan_aufgabe(f["pfad"], int(f["phase"]), f.get("text", ""), f.get("wer", ""), f.get("bis", ""),
                               f.get("prio", ""), f.get("unter", ""))
        _ok(f"Aufgabe als Task angelegt: {AGENT.rel(t)}")
    except Exception as exc:
        _fehler(exc)
    return redirect(url_for("projektplan", pfad=f["pfad"]))


@app.post("/projektplan/phase")
def projektplan_phase():
    f = request.form
    try:
        if f.get("status"):
            AGENT.plan_phase_status(f["pfad"], int(f["phase"]), f["status"])
        else:
            AGENT.plan_phase(f["pfad"], f.get("name", ""))
            _ok("Phase hinzugefügt.")
    except Exception as exc:
        _fehler(exc)
    return redirect(url_for("projektplan", pfad=f["pfad"]))


@app.post("/projektplan/notiz")
def projektplan_notiz():
    f = request.form
    try:
        AGENT.plan_notiz(f["pfad"], f.get("text", ""))
    except Exception as exc:
        _fehler(exc)
    return redirect(url_for("projektplan", pfad=f["pfad"]))


@app.post("/projektplan/status")
def projektplan_status():
    f = request.form
    try:
        p = AGENT.abs_in_vault(f["pfad"])
        p.write_text(core.set_frontmatter(p.read_text(encoding="utf-8"), {"status": f["status"]}), encoding="utf-8")
        with AGENT.db() as con:
            AGENT._index_file(con, p, dt.date.today())
    except Exception as exc:
        _fehler(exc)
    return redirect(url_for("projektplan", pfad=f["pfad"]))


@app.get("/projektplan/outlook")
def projektplan_outlook():
    """Statusbericht (gesamt oder eine Phase) als E-Mail-Entwurf (.eml) für Outlook."""
    phase = request.args.get("phase")
    name, daten = AGENT.plan_eml(request.args["pfad"], int(phase) if phase not in (None, "") else None)
    return Response(daten, mimetype="message/rfc822",
                    headers={"Content-Disposition": f"attachment; filename*=UTF-8''{urllib.parse.quote(name)}"})


@app.get("/projektplan/vorschau")
def projektplan_vorschau():
    phase = request.args.get("phase")
    m = AGENT.plan_mail(request.args["pfad"], int(phase) if phase not in (None, "") else None)
    return render_template("protokoll_vorschau.html", m=m, pfad=request.args["pfad"],
                           link=AGENT.obsidian_link(request.args["pfad"]),
                           outlook=url_for("projektplan_outlook", pfad=request.args["pfad"], phase=phase or ""),
                           mailto="mailto:" + ",".join(m["an"]) + "?" + urllib.parse.urlencode(
                               {"subject": m["betreff"], "body": m["text"]}, quote_via=urllib.parse.quote),
                           zurueck=url_for("projektplan", pfad=request.args["pfad"]))


# --- Aus Vorlage -------------------------------------------------------------------
@app.route("/vorlage")
def vorlage():
    return render_template("vorlage.html", vorlagen=AGENT.vorlagen_liste(), projekte=AGENT.projekte(),
                           projekt=request.args.get("projekt", ""), gewaehlt=request.args.get("vorlage", ""),
                           notizen=AGENT.letzte_notizen(12))


@app.post("/vorlage/neu")
def vorlage_neu():
    f = request.form
    try:
        p = AGENT.aus_vorlage_anlegen(f.get("vorlage", ""), f.get("titel", ""), f.get("projekt", ""),
                                      f.get("unterordner", ""))
        _ok(f"Notiz angelegt: {AGENT.rel(p)}")
        return redirect(url_for("vorlage", projekt=f.get("projekt", ""), vorlage=f.get("vorlage", "")))
    except Exception as exc:
        _fehler(exc)
    return redirect(request.referrer or url_for("vorlage"))


# --- DevOps ------------------------------------------------------------------------
@app.route("/devops")
def devops():
    eintraege = AGENT.eintraege("devops")
    kat = request.args.get("kategorie", "")
    if kat:
        eintraege = [e for e in eintraege if e["kategorie"] == kat]
    return render_template("devops.html", eintraege=eintraege, kat=kat, kategorien=core.DEVOPS_KATEGORIEN,
                           status_liste=core.DEVOPS_STATUS, umgebungen=core.UMGEBUNGEN,
                           projekte=AGENT.projekte(), team=AGENT.eintraege("person"))


@app.post("/devops/neu")
def devops_neu():
    try:
        _ok(f"DevOps-Eintrag angelegt: {AGENT.rel(AGENT.devops_anlegen(request.form.to_dict()))}")
    except Exception as exc:
        _fehler(exc)
    return redirect(url_for("devops"))


# --- Ideenbox ---------------------------------------------------------------------
@app.route("/ideen")
def ideen():
    alle = AGENT.eintraege("idee")
    spalten = {s: [i for i in alle if (i.get("status") or "neu") == s] for s in core.IDEEN_STATUS}
    return render_template("ideen.html", spalten=spalten, status_liste=core.IDEEN_STATUS, stufen=core.STUFEN,
                           projekte=AGENT.projekte(), team=AGENT.eintraege("person"), anzahl=len(alle))


@app.post("/ideen/neu")
def idee_neu():
    try:
        _ok(f"Idee gespeichert: {AGENT.rel(AGENT.idee_anlegen(request.form.to_dict()))}")
    except Exception as exc:
        _fehler(exc)
    return redirect(url_for("ideen"))


@app.post("/ideen/task")
def idee_task():
    f = request.form
    try:
        t = AGENT.idee_zu_task(f["pfad"], f.get("start", ""), f.get("ende", ""), f.get("verantwortlich", ""))
        _ok(f"Task erstellt: {AGENT.rel(t)}. Die Idee steht jetzt auf „angenommen“.")
    except Exception as exc:
        _fehler(exc)
    return redirect(url_for("ideen"))


@app.post("/feld")
def feld():
    f = request.form
    try:
        AGENT.feld_setzen(f["pfad"], f["feld"], f["wert"])
    except Exception as exc:
        _fehler(exc)
    return redirect(request.referrer or url_for("dashboard"))


# --- Team -------------------------------------------------------------------------
@app.route("/team")
def team():
    return render_template("team.html", team=AGENT.team())


@app.post("/team/neu")
def person_neu():
    try:
        _ok(f"Teammitglied angelegt: {AGENT.rel(AGENT.person_anlegen(request.form.to_dict()))}")
    except Exception as exc:
        _fehler(exc)
    return redirect(url_for("team"))


# --- Wiki ------------------------------------------------------------------------
@app.route("/wiki")
def wiki():
    q = request.args.get("q", "").strip()
    treffer = AGENT.suche(q, typ="wiki") if q else None
    return render_template("wiki.html", artikel=AGENT.wiki_artikel(), q=q, treffer=treffer,
                           kategorien=AGENT.wiki_kategorien(), gewaehlt=request.args.get("kategorie", ""))


@app.post("/wiki/neu")
def wiki_neu():
    f = request.form
    try:
        kat = f.get("kategorie_neu", "").strip() if f.get("kategorie") == "__neu__" else f.get("kategorie", "")
        p = AGENT.wiki_anlegen(f["titel"], kat, f.get("tags", ""), f.get("inhalt", ""))
        _ok(f"Wiki-Artikel angelegt: {AGENT.rel(p)}")
    except Exception as exc:
        _fehler(exc)
    return redirect(url_for("wiki"))


@app.post("/wiki/kategorie")
def wiki_kategorie_neu():
    f = request.form
    try:
        d = AGENT.wiki_kategorie_anlegen(f.get("name", ""), f.get("eltern", ""))
        kat = d.relative_to(AGENT.ordner("wiki_ordner")).as_posix()
        _ok(f"Kategorie angelegt: {AGENT.rel(d)}")
        return redirect(url_for("wiki", kategorie=kat))
    except Exception as exc:
        _fehler(exc)
    return redirect(url_for("wiki"))


# --- Jour Fixe ------------------------------------------------------------------
@app.route("/jourfixe")
def jourfixe():
    serie = request.args.get("serie", "")
    erledigte = request.args.get("erledigte") == "1"
    return render_template("jourfixe.html", serie=serie, erledigte=erledigte,
                           serien=AGENT.jf_serien(), pendenzen=AGENT.jf_pendenzen(serie, alle=erledigte),
                           sitzungen=AGENT.jf_sitzungen(serie)[:15], projekte=AGENT.projekte(),
                           turnus=list(core.JF_TURNUS))


@app.post("/jourfixe/sitzung")
def jf_sitzung_neu():
    f = request.form.to_dict()
    if f.get("serie") == "__neu__":
        f["serie"] = f.get("serie_neu", "")
    try:
        p = AGENT.jf_sitzung_anlegen(f)
        _ok(f"Jour-Fixe-Sitzung angelegt: {AGENT.rel(p)}. Sie enthält die offenen Pendenzen der Serie.")
        return redirect(url_for("jourfixe", serie=core.safe_name(f["serie"])))
    except Exception as exc:
        _fehler(exc)
    return redirect(request.referrer or url_for("jourfixe"))


@app.post("/jourfixe/pendenz")
def jf_pendenz_neu():
    try:
        p = AGENT.jf_pendenz_anlegen(request.form.to_dict())
        _ok(f"Pendenz angelegt: {AGENT.rel(p)}")
    except Exception as exc:
        _fehler(exc)
    return redirect(request.referrer or url_for("jourfixe"))


# --- LifeCycle -------------------------------------------------------------------
@app.route("/lcm")
def lcm():
    eintraege = AGENT.lcm_eintraege()
    kat = request.args.get("kategorie", "")
    if kat:
        eintraege = [e for e in eintraege if e["kategorie"] == kat]
    return render_template("lcm.html", eintraege=eintraege, kat=kat, kategorien=core.LCM_KATEGORIEN,
                           status_liste=core.LCM_STATUS, projekte=AGENT.projekte())


@app.post("/lcm/neu")
def lcm_neu():
    try:
        p = AGENT.lcm_anlegen(request.form.to_dict())
        _ok(f"LifeCycle-Eintrag angelegt: {AGENT.rel(p)}")
    except Exception as exc:
        _fehler(exc)
    return redirect(url_for("lcm"))


# --- Notizen aus Vorlagen -----------------------------------------------------------
@app.route("/notizen")
def notizen():
    typen = {k: core.VORLAGEN[k] for k in core.NOTIZ_TYPEN}
    return render_template("notizen.html", typen=typen, projekte=AGENT.projekte(),
                           notizen=AGENT.letzte_notizen(30))


@app.post("/notizen/neu")
def notiz_neu():
    f = request.form
    try:
        p = AGENT.notiz_anlegen(f["typ"], f["titel"], f.get("projekt", ""))
        _ok(f"Notiz angelegt: {AGENT.rel(p)}")
    except Exception as exc:
        _fehler(exc)
    return redirect(url_for("notizen"))


# --- Suche -------------------------------------------------------------------------
@app.route("/suche")
def suche():
    q = request.args.get("q", "").strip()
    return render_template("suche.html", q=q, treffer=AGENT.suche(q) if q else None)


# --- Einstellungen -----------------------------------------------------------------
FELDER = ["vault_path", "projekt_ordner", "task_ordner", "wiki_ordner", "lcm_ordner",
          "notiz_ordner", "vorlagen_ordner", "planer_ordner", "devops_ordner", "ideen_ordner", "team_ordner", "jourfixe_ordner", "task_standard_ordner", "protokoll_ordner", "plan_ordner", "sync_zeit",
          "lcm_warnung_tage", "demnaechst_tage"]


@app.route("/einstellungen", methods=["GET", "POST"])
def einstellungen():
    if request.method == "POST":
        for k in FELDER:
            if k in request.form:
                v = request.form[k].strip()
                AGENT.cfg[k] = int(v) if k.endswith("_tage") and v.isdigit() else v
        core.save_config(AGENT.cfg)
        if AGENT.vault_ok():
            try:
                AGENT.sync("manuell")
                _ok("Einstellungen gespeichert und Vault eingelesen.")
            except Exception as exc:
                _fehler(exc)
        else:
            flash(f"Gespeichert – aber der Vault-Ordner existiert nicht: {AGENT.vault}", "fehler")
        return redirect(url_for("einstellungen"))
    return render_template("einstellungen.html", felder=FELDER, log=AGENT.sync_log(15),
                           db=AGENT.db_path, faellig=AGENT.geplanter_sync_faellig())


if __name__ == "__main__":
    port = int(AGENT.cfg.get("port", 5055))
    AGENT.starte_scheduler()
    if not os.environ.get("OBSIDIAN_AGENT_NO_BROWSER"):  # z.B. beim Autostart (macOS LaunchAgent)
        threading.Timer(1.2, lambda: webbrowser.open(f"http://127.0.0.1:{port}")).start()
    print(f"Obsidian-Agent läuft auf http://127.0.0.1:{port}  (Beenden mit Ctrl+C)")
    app.run(host="127.0.0.1", port=port, debug=False)
