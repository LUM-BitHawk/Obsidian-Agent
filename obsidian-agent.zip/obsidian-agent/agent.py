"""
Obsidian-Agent – Kernlogik
==========================
Verwaltet einen Obsidian-Vault (Markdown bleibt die "Wahrheit") und führt
eine lokale SQLite-Datenbank als Planer/Index:

  * Projekte mit fester Ordnerstruktur anlegen
  * Task_*.md Dateien einlesen -> Tagesübersicht (heute / überfällig / demnächst)
  * Wiki-Artikel, LifeCycle-Einträge (LCM_*.md), Notizen aus Vorlagen
  * Volltextsuche über den ganzen Vault
  * Täglicher Sync (Standard 04:00) – im GUI-Prozess oder per Windows-Aufgabenplanung

CLI:
  python agent.py sync               # Vault einlesen, Tagesübersicht schreiben
  python agent.py sync --geplant     # wie oben, zählt als geplanter 04:00-Lauf
  python agent.py heute              # heutige Tasks in der Konsole anzeigen
  python agent.py projekt "Name"     # neues Projekt anlegen
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import re
import sqlite3
import sys
import threading
import time
import urllib.parse
from pathlib import Path

VERSION = "2026-11-24.3"   # wird in der Oberfläche unten links angezeigt
BASE_DIR = Path(__file__).resolve().parent
CONFIG_FILE = BASE_DIR / "config.json"

DEFAULT_CONFIG = {
    "vault_path": str(Path.home() / "Documents" / "Obsidian"),
    "db_path": "planer.db",            # relativ zum Programmordner oder absolut
    "projekt_ordner": "Projekte",      # leer = Projekte direkt im Vault-Root
    "task_ordner": "Tasks",            # Tasks ohne Projekt
    "wiki_ordner": "Wiki",
    "lcm_ordner": "LifeCycle",
    "notiz_ordner": "Notizen",         # Notizen ohne Projekt
    "vorlagen_ordner": "_Vorlagen",
    "planer_ordner": "Planer",
    "devops_ordner": "DevOps",
    "ideen_ordner": "Ideenbox",
    "team_ordner": "Team",
    "jourfixe_ordner": "JourFixe",
    "task_standard_ordner": "",
    "protokoll_ordner": "06_Projekte",
    "plan_ordner": "06_Projekte",        # Unterordner im Projekt für Projektpläne (Projektaufgaben) und deren Tasks   # Unterordner im Projekt für Projektprotokolle und deren Aufgaben      # vorgewählter Unterordner für Tasks im Projekt (leer = Projektordner)
    "sync_zeit": "04:00",
    "lcm_warnung_tage": 90,
    "demnaechst_tage": 7,
    "port": 5055,
    "eigene_projekt_ordner": {},       # zusätzliche Standard-Ordner für Projekte {name: zweck}
}

PROJEKT_STRUKTUR = {
    "01_Vertraege_und_SLA": "Verträge, Service Level Agreements, Angebote, Bestellungen und Nachträge.",
    "02_Kontakte_und_Eskalation": "Ansprechpartner, Rollen, Eskalationsstufen und Erreichbarkeiten.",
    "03_Technische_Dokumentation": "Architektur, Netzwerkpläne, Konfigurationen und Entscheidungen (ADR).",
    "04_Betrieb_und_Wartung": "Runbooks, Wartungsfenster, Changes, Störungen und Checklisten.",
    "05_Reporting_und_KPIs": "Monats-/Quartalsreports, KPIs und SLA-Erfüllung.",
    "06_Projekte": "Teilprojekte, Projektpläne und Meilensteine.",
    "07_DevOps": "Pipelines, Deployments, Umgebungen, Skripte, Repositories, Monitoring und Infrastruktur als Code.",
    "10_Korrespondenz": "Meeting-Protokolle, wichtige E-Mails und Schriftverkehr.",
}

TASK_STATUS = ["offen", "in_arbeit", "wartend", "erledigt"]
ERLEDIGT_WERTE = {"erledigt", "done", "abgeschlossen", "fertig", "x", "true", "ja", "closed"}
PRIO_ORDER = {"hoch": 0, "mittel": 1, "niedrig": 2}

LCM_KATEGORIEN = ["Hardware", "Software", "Lizenz", "Zertifikat", "Vertrag", "Service"]
LCM_STATUS = ["Planung", "Beschaffung", "Betrieb", "Auslauf", "Ausser Betrieb"]

# ---------------------------------------------------------------------------
# Vorlagen (werden beim ersten Start in <Vault>/_Vorlagen geschrieben und
# können danach in Obsidian frei angepasst werden). Platzhalter {{title}} und
# {{date}} sind kompatibel mit dem Obsidian-Kern-Plugin "Vorlagen".
# ---------------------------------------------------------------------------
VORLAGEN: dict[str, dict] = {
    "task": {
        "label": "Task",
        "datei": "Vorlage_Task.md",
        "ordner": None,
        "dateiname": "Task_{titel_}",
        "text": """---
typ: task
titel: {{title}}
projekt: {{projekt}}
start: {{start}}
ende: {{ende}}
status: offen
prioritaet: {{prioritaet}}
verantwortlich: {{verantwortlich}}
erstellt: {{date}}
tags: [task]
---
# {{title}}

## Beschreibung
{{beschreibung}}

## Checkliste
{{checkliste}}

## Notizen
""",
    },
    "meeting": {
        "label": "Meeting-Protokoll",
        "datei": "Vorlage_Meeting.md",
        "ordner": "10_Korrespondenz",
        "dateiname": "{date}_Meeting_{titel_}",
        "text": """---
typ: meeting
titel: {{title}}
projekt: {{projekt}}
datum: {{date}}
teilnehmende:
tags: [meeting]
---
# Meeting: {{title}}
**Datum:** {{date}}  **Projekt:** {{projekt}}

## Teilnehmende
-

## Traktanden
1.

## Besprochen / Ergebnisse
-

## Entscheidungen
-

## Aktionspunkte
> Tipp: Für jeden Aktionspunkt im Agent einen Task anlegen – dann erscheint er in der Tagesübersicht.

| Was | Wer | Bis |
|-----|-----|-----|
|     |     |     |
""",
    },
    "entscheidung": {
        "label": "Entscheidung (ADR)",
        "datei": "Vorlage_Entscheidung.md",
        "ordner": "03_Technische_Dokumentation",
        "dateiname": "ADR_{date}_{titel_}",
        "text": """---
typ: entscheidung
titel: {{title}}
projekt: {{projekt}}
datum: {{date}}
status: vorgeschlagen
tags: [entscheidung, adr]
---
# Entscheidung: {{title}}

## Kontext
Was ist die Ausgangslage, welches Problem lösen wir?

## Optionen
1.
2.

## Entscheidung
Wir haben uns entschieden für …

## Begründung

## Konsequenzen
""",
    },
    "runbook": {
        "label": "Runbook / Anleitung",
        "datei": "Vorlage_Runbook.md",
        "ordner": "04_Betrieb_und_Wartung",
        "dateiname": "Runbook_{titel_}",
        "text": """---
typ: runbook
titel: {{title}}
projekt: {{projekt}}
erstellt: {{date}}
review:
tags: [runbook]
---
# Runbook: {{title}}

## Zweck

## Voraussetzungen / Zugänge
-

## Schritte
1. [ ]
2. [ ]
3. [ ]

## Prüfung (Wie weiss ich, dass es funktioniert hat?)

## Rollback
""",
    },
    "change": {
        "label": "Change",
        "datei": "Vorlage_Change.md",
        "ordner": "04_Betrieb_und_Wartung",
        "dateiname": "Change_{date}_{titel_}",
        "text": """---
typ: change
titel: {{title}}
projekt: {{projekt}}
datum: {{date}}
status: geplant
risiko: mittel
wartungsfenster:
tags: [change]
---
# Change: {{title}}

## Beschreibung

## Betroffene Systeme / Services

## Risiko & Auswirkung

## Durchführung

## Rollback-Plan

## Ergebnis
""",
    },
    "stoerung": {
        "label": "Störung / Incident",
        "datei": "Vorlage_Stoerung.md",
        "ordner": "04_Betrieb_und_Wartung",
        "dateiname": "Incident_{date}_{titel_}",
        "text": """---
typ: stoerung
titel: {{title}}
projekt: {{projekt}}
beginn: {{date}}
ende:
prioritaet: P2
status: offen
tags: [incident]
---
# Störung: {{title}}

## Symptome / Auswirkung

## Zeitlinie
- {{date}} – Störung gemeldet

## Ursache (Root Cause)

## Lösung

## Massnahmen (Lessons Learned)
""",
    },
    "kontakt": {
        "label": "Kontakt",
        "datei": "Vorlage_Kontakt.md",
        "ordner": "02_Kontakte_und_Eskalation",
        "dateiname": "Kontakt_{titel_}",
        "text": """---
typ: kontakt
titel: {{title}}
projekt: {{projekt}}
firma:
rolle:
telefon:
email:
eskalationsstufe:
tags: [kontakt]
---
# {{title}}

| Feld | Wert |
|------|------|
| Firma | |
| Rolle | |
| Telefon | |
| E-Mail | |
| Eskalationsstufe | |

## Notizen
""",
    },
    "report": {
        "label": "Report",
        "datei": "Vorlage_Report.md",
        "ordner": "05_Reporting_und_KPIs",
        "dateiname": "Report_{monat}_{titel_}",
        "text": """---
typ: report
titel: {{title}}
projekt: {{projekt}}
periode:
erstellt: {{date}}
tags: [report]
---
# Report: {{title}}

## Zusammenfassung

## KPIs
| KPI | Ziel | Ist | Status |
|-----|------|-----|--------|
|     |      |     |        |

## Highlights

## Probleme / Risiken

## Nächste Schritte
""",
    },
    "wiki": {
        "label": "Wiki-Artikel",
        "datei": "Vorlage_Wiki.md",
        "ordner": None,
        "dateiname": "{titel}",
        "text": """---
typ: wiki
titel: {{title}}
kategorie: {{kategorie}}
erstellt: {{date}}
tags: [{{tags}}]
---
# {{title}}

{{inhalt}}

## Siehe auch
-
""",
    },
    "lcm": {
        "label": "LifeCycle-Eintrag",
        "datei": "Vorlage_LCM.md",
        "ordner": None,
        "dateiname": "LCM_{titel_}",
        "text": """---
typ: lcm
titel: {{title}}
kategorie: {{kategorie}}
hersteller: {{hersteller}}
produkt: {{produkt}}
version: {{version}}
projekt: {{projekt}}
standort: {{standort}}
inbetriebnahme: {{inbetriebnahme}}
end_of_support: {{end_of_support}}
end_of_life: {{end_of_life}}
status: {{status}}
verantwortlich: {{verantwortlich}}
tags: [lcm]
---
# {{title}}

## Beschreibung
{{beschreibung}}

## Lebenszyklus
| Phase | Datum |
|-------|-------|
| Inbetriebnahme | {{inbetriebnahme}} |
| End of Support | {{end_of_support}} |
| End of Life | {{end_of_life}} |

## Nachfolger / Ersatzplanung

## Historie
- {{date}} – Eintrag erstellt
""",
    },
}

VORLAGEN["devops"] = {
    "label": "DevOps-Eintrag", "datei": "Vorlage_DevOps.md", "ordner": None, "dateiname": "{titel}",
    "text": """---
typ: devops
titel: {{title}}
kategorie: {{kategorie}}
projekt: {{projekt}}
umgebung: {{umgebung}}
status: {{status}}
repository: {{repository}}
verantwortlich: {{verantwortlich}}
datum: {{date}}
tags: [devops]
---
# {{title}}

## Beschreibung
{{beschreibung}}

## Ablauf / Befehle
```bash

```

## Konfiguration / Variablen
| Name | Wert | Umgebung |
|------|------|----------|
|      |      |          |

## Abhängigkeiten
-

## Links
- Repository: {{repository}}

## Historie
- {{date}} – Eintrag erstellt
""",
}
VORLAGEN["idee"] = {
    "label": "Idee", "datei": "Vorlage_Idee.md", "ordner": None, "dateiname": "Idee_{date}_{titel_}",
    "text": """---
typ: idee
titel: {{title}}
kategorie: {{kategorie}}
projekt: {{projekt}}
eingereicht_von: {{eingereicht_von}}
datum: {{date}}
status: neu
nutzen: {{nutzen}}
aufwand: {{aufwand}}
task:
tags: [idee]
---
# 💡 {{title}}

## Ausgangslage / Problem
{{problem}}

## Idee
{{beschreibung}}

## Nutzen

## Aufwand / Risiken

## Entscheid
""",
}
VORLAGEN["person"] = {
    "label": "Teammitglied", "datei": "Vorlage_Teammitglied.md", "ordner": None, "dateiname": "{titel}",
    "text": """---
typ: person
titel: {{title}}
kuerzel: {{kuerzel}}
rolle: {{rolle}}
team: {{team}}
email: {{email}}
telefon: {{telefon}}
standort: {{standort}}
vertretung: {{vertretung}}
skills: {{skills}}
tags: [team]
---
# {{title}}

| Feld | Wert |
|------|------|
| Rolle | {{rolle}} |
| Team | {{team}} |
| E-Mail | {{email}} |
| Telefon | {{telefon}} |
| Standort | {{standort}} |
| Vertretung | {{vertretung}} |

## Aufgaben & Verantwortlichkeiten
-

## Skills / Zertifizierungen
{{skills}}

## Abwesenheiten
| Von | Bis | Grund |
|-----|-----|-------|
|     |     |       |

## Notizen
""",
}

VORLAGEN["jourfixe"] = {
    "label": "Jour Fixe", "datei": "Vorlage_JourFixe.md", "ordner": None, "dateiname": "JF_{datum}_{serie}",
    "text": """---
typ: jourfixe
titel: {{title}}
serie: {{serie}}
datum: {{datum}}
projekt: {{projekt}}
moderation: {{moderation}}
teilnehmer: {{teilnehmer}}
naechster_termin: {{naechster_termin}}
tags: [jourfixe]
---
# {{title}}

**Datum:** {{datum}} · **Moderation:** {{moderation}} · **Nächster Termin:** {{naechster_termin}}
**Teilnehmende:** {{teilnehmer}}

## Traktanden
{{agenda}}

## Offene Pendenzen (Stand vor der Sitzung)
{{pendenzen}}

## Informationen / Diskussion
-

## Beschlüsse
-

## Neue Pendenzen
> Neue Pendenzen im Obsidian-Agent unter *Jour Fixe → Neue Pendenz* erfassen.
> Sie erscheinen dann auch unter Tasks, Heute und bei den Teammitgliedern.
""",
}

VORLAGEN["devops_doku"] = {
    "label": "DevOps-Dokumentation", "datei": "Vorlage_DevOps_Dokumentation.md", "ordner": "07_DevOps",
    "dateiname": "DevOps_{titel_}",
    "text": """---
typ: devops
titel: {{title}}
kategorie: 
projekt: {{projekt}}
umgebung: 
status: aktiv
repository: 
verantwortlich: 
datum: {{date}}
tags: [devops, dokumentation]
---
# {{title}}

> Projekt: {{projekt}} · erstellt am {{date}}
> Kategorie, Umgebung (Dev/Test/Staging/Prod) und Repository oben in den Eigenschaften ergänzen.
> Dann erscheint der Eintrag mit Status auch im Obsidian-Agent unter **DevOps**.

## Zweck
Was wird hier gebaut, ausgeliefert oder betrieben, und warum?

## Umgebungen
| Umgebung | Server / URL | Version | Bemerkung |
|---|---|---|---|
| Dev | | | |
| Test | | | |
| Staging | | | |
| Prod | | | |

## Ablauf / Befehle
1. 
```powershell

```

## Konfiguration / Variablen
| Name | Wert / Ort im Passwort-Tresor | Umgebung |
|---|---|---|
| | | |

> Keine Passwörter oder Secrets in dieser Notiz – nur angeben, wo sie liegen.

## Rollback
- 

## Monitoring / Prüfung nach dem Deployment
- [ ] Dienst läuft
- [ ] Logs ohne Fehler
- [ ] Funktionstest durchgeführt

## Abhängigkeiten
- 

## Historie
| Datum | Änderung | Wer |
|---|---|---|
| {{date}} | Dokumentation erstellt | |
""",
}

VORLAGEN["projektprotokoll"] = {
    "label": "Projektprotokoll", "datei": "Vorlage_Projektprotokoll.md", "ordner": "06_Projekte",
    "dateiname": "Projektprotokoll_{date}_{titel_}",
    "text": """---
type: projektprotokoll
projekt: "{{projekt_link}}"
datum: {{datum}}
status: {{status}}
tags:
  - projektprotokoll
  - meeting
---

# Projektprotokoll: {{projekt}} – {{datum}}

**Projekt:** {{projekt_link}}  
**Datum / Zeit:** {{datum_zeit}}  
**Teilnehmende:** {{teilnehmer}}  
**Moderation:** {{moderation}}  

## Kurzfassung
{{kurzfassung}}

## Agenda & Besprochenes
{{agenda}}

## Beschlüsse / Entscheidungen
{{beschluesse}}

## Aufgaben (Action Items)
{{aufgaben}}

## Offene Punkte & Risiken
{{offene_punkte}}

## Nächstes Treffen
- **Termin:** {{naechster_termin}}
- **Themen:** {{naechste_themen}}
""",
}

PROTOKOLL_STATUS = ["offen", "versendet", "abgeschlossen"]

JF_TURNUS = {"wöchentlich": 7, "alle 2 Wochen": 14, "alle 4 Wochen": 28, "monatlich": 0}

DEVOPS_KATEGORIEN = ["Pipeline", "Deployment", "Umgebung", "Skript", "Repository", "Monitoring", "Infrastruktur"]
DEVOPS_STATUS = ["geplant", "aktiv", "erfolgreich", "fehlgeschlagen", "veraltet"]
UMGEBUNGEN = ["", "Dev", "Test", "Staging", "Prod"]
IDEEN_STATUS = ["neu", "in_pruefung", "angenommen", "umgesetzt", "abgelehnt"]
STUFEN = ["hoch", "mittel", "niedrig"]

NOTIZ_TYPEN = ["meeting", "entscheidung", "runbook", "change", "stoerung", "kontakt", "report", "devops_doku"]


# ---------------------------------------------------------------------------
# Hilfsfunktionen
# ---------------------------------------------------------------------------
FM_RE = re.compile(r"\A---[ \t]*\r?\n(.*?)^---[ \t]*(?:\r?\n|\Z)", re.S | re.M)
CHECK_RE = re.compile(r"^\s*[-*+] \[([ xX])\]", re.M)


def load_config() -> dict:
    cfg = dict(DEFAULT_CONFIG)
    if CONFIG_FILE.exists():
        try:
            cfg.update(json.loads(CONFIG_FILE.read_text(encoding="utf-8")))
        except json.JSONDecodeError:
            pass
    else:
        save_config(cfg)
    return cfg


def save_config(cfg: dict) -> None:
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding="utf-8")


def safe_name(name: str, underscore: bool = False) -> str:
    name = re.sub(r'[\\/:*?"<>|#^\[\]]', "", str(name)).strip().strip(".")
    name = re.sub(r"\s+", "_" if underscore else " ", name)
    return name[:120]


def parse_frontmatter(text: str) -> tuple[dict, str]:
    m = FM_RE.match(text)
    if not m:
        return {}, text
    data = {}
    for line in m.group(1).splitlines():
        if not line.strip() or line.lstrip().startswith("#") or ":" not in line:
            continue
        if line[0] in " \t-":
            continue  # verschachtelte Werte / Listen-Einträge ignorieren
        k, v = line.split(":", 1)
        v = v.strip()
        if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
            v = v[1:-1]
        data[k.strip().lower()] = v
    return data, text[m.end():]


def fm_value(v) -> str:
    v = "" if v is None else str(v)
    if v.startswith("[["):  # Wiki-Link als Property: in Obsidian nur in Anführungszeichen gültig
        return json.dumps(v, ensure_ascii=False)
    if re.search(r"[:#]\s|^[\[{&*!|>%@`]", v) and not re.match(r"^\[.*\]$", v):
        return json.dumps(v, ensure_ascii=False)
    return v


def set_frontmatter(text: str, values: dict) -> str:
    m = FM_RE.match(text)
    if not m:
        block = [f"{k}: {fm_value(v)}" for k, v in values.items()]
        return "---\n" + "\n".join(block) + "\n---\n" + text
    block = m.group(1).rstrip("\r\n").split("\n") if m.group(1).strip() else []
    for k, v in values.items():
        line = f"{k}: {fm_value(v)}"
        for i, existing in enumerate(block):
            if re.match(rf"^{re.escape(k)}\s*:", existing, re.I):
                block[i] = line
                break
        else:
            block.append(line)
    return "---\n" + "\n".join(block) + "\n---\n" + text[m.end():]


def parse_date(v) -> dt.date | None:
    if not v:
        return None
    s = str(v).strip().strip("[]\"' ")
    if not s:
        return None
    try:
        return dt.date.fromisoformat(s[:10])
    except ValueError:
        pass
    for fmt in ("%d.%m.%Y", "%d.%m.%y", "%Y/%m/%d", "%d/%m/%Y"):
        try:
            return dt.datetime.strptime(s, fmt).date()
        except ValueError:
            continue
    return None


WIKILINK_RE = re.compile(r"\[\[([^\]|]+)(?:\|([^\]]+))?\]\]")


def link_name(v) -> str:
    """'[[_Projekt_X|X]]' -> 'X', '[[X]]' -> 'X', 'X' -> 'X'."""
    v = "" if v is None else str(v).strip().strip('"\'')
    m = WIKILINK_RE.fullmatch(v)
    if m:
        return (m.group(2) or m.group(1).split("/")[-1]).strip()
    return v


def wikilinks(namen: str) -> str:
    """'Anna Keller, MST' -> '[[Anna Keller]], [[MST]]' (bereits verlinkte Namen bleiben)."""
    out = []
    for n in re.split(r"[,;]", namen or ""):
        n = n.strip()
        if n:
            out.append(n if n.startswith("[[") else f"[[{n}]]")
    return ", ".join(out)


def md_zu_html(md: str) -> str:
    """Kleiner Markdown-Umsetzer für E-Mails (Überschriften, Listen, Checkboxen, fett/kursiv, Wiki-Links)."""
    import html as _h
    _, body = parse_frontmatter(md)

    def inline(t: str) -> str:
        t = _h.escape(t, quote=False)
        t = WIKILINK_RE.sub(lambda m: (m.group(2) or m.group(1).split("/")[-1]), t)
        t = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t)
        t = re.sub(r"(?<![*\w])\*(?!\s)(.+?)(?<!\s)\*(?!\w)", r"<i>\1</i>", t)
        return t

    teile, liste = [], False
    for zeile in body.splitlines():
        roh = zeile.rstrip()
        m_check = re.match(r"^\s*[-*] \[([ xX])\]\s?(.*)$", roh)
        m_li = re.match(r"^\s*[-*] (.*)$", roh)
        if m_check or m_li:
            if not liste:
                teile.append('<ul style="margin:4px 0 10px 0;padding-left:20px">')
                liste = True
            if m_check:
                box = "&#9745;" if m_check.group(1).lower() == "x" else "&#9744;"
                teile.append(f'<li style="list-style:none;margin-left:-18px">{box} {inline(m_check.group(2))}</li>')
            else:
                teile.append(f"<li>{inline(m_li.group(1)) or '&nbsp;'}</li>")
            continue
        if liste:
            teile.append("</ul>")
            liste = False
        m_h = re.match(r"^(#{1,4})\s+(.*)$", roh)
        if m_h:
            n = len(m_h.group(1))
            groesse = {1: "20px", 2: "15px", 3: "13px", 4: "13px"}[n]
            teile.append(f'<h{n} style="font-size:{groesse};margin:16px 0 6px 0;color:#1f1a2e">{inline(m_h.group(2))}</h{n}>')
        elif roh.strip():
            umbruch = "<br>" if zeile.endswith("  ") else ""
            teile.append(f'<div style="margin:2px 0">{inline(roh.strip())}{umbruch}</div>')
    if liste:
        teile.append("</ul>")
    return ('<div style="font-family:Calibri,Arial,sans-serif;font-size:11pt;color:#222;line-height:1.45">'
            + "\n".join(teile) + "</div>")


def md_zu_text(md: str) -> str:
    _, body = parse_frontmatter(md)
    t = WIKILINK_RE.sub(lambda m: (m.group(2) or m.group(1).split("/")[-1]), body)
    t = re.sub(r"\*\*(.+?)\*\*", r"\1", t)
    t = re.sub(r"(?m)^#{1,4}\s+(.*)$", lambda m: m.group(1).upper() if m.group(0).startswith("# ") else m.group(1), t)
    t = t.replace("- [ ] ", "[ ] ").replace("- [x] ", "[x] ")
    return re.sub(r"\n{3,}", "\n\n", t).strip() + "\n"


def iso(d: dt.date | None) -> str | None:
    return d.isoformat() if d else None


def dmy(s) -> str:
    d = parse_date(s)
    return d.strftime("%d.%m.%Y") if d else ""


def task_kategorie(t: dict, heute: dt.date) -> str:
    """heute | ueberfaellig | geplant | ohne_datum | erledigt"""
    if t.get("status") == "erledigt":
        return "erledigt"
    start = parse_date(t.get("start"))
    ende = parse_date(t.get("ende"))
    if not start and not ende:
        return "ohne_datum"
    start = start or ende
    ende = ende or start
    if ende < heute:
        return "ueberfaellig"
    if start > heute:
        return "geplant"
    return "heute"


def lcm_ampel(e: dict, heute: dt.date, warn_tage: int) -> dict:
    status = (e.get("status") or "").lower()
    if status in ("ausser betrieb", "ausgemustert", "entsorgt"):
        return {"farbe": "grau", "text": "Ausser Betrieb", "tage": None}
    eos = parse_date(e.get("end_of_support"))
    eol = parse_date(e.get("end_of_life"))
    if eol and eol < heute:
        return {"farbe": "rot", "text": "End of Life erreicht", "tage": (eol - heute).days}
    if eos and eos < heute:
        return {"farbe": "rot", "text": "Support beendet", "tage": (eos - heute).days}
    kandidaten = [(d, n) for d, n in ((eos, "EOS"), (eol, "EOL")) if d]
    if not kandidaten:
        return {"farbe": "grau", "text": "Keine Daten", "tage": None}
    d, n = min(kandidaten)
    tage = (d - heute).days
    if tage <= warn_tage:
        return {"farbe": "orange", "text": f"{n} in {tage} Tagen", "tage": tage}
    if tage <= warn_tage * 2:
        return {"farbe": "gelb", "text": f"{n} in {tage} Tagen", "tage": tage}
    return {"farbe": "gruen", "text": f"{n} in {tage} Tagen", "tage": tage}


def render_vorlage(text: str, werte: dict) -> str:
    for k, v in werte.items():
        text = text.replace("{{" + k + "}}", "" if v is None else str(v))
    return re.sub(r"\{\{[a-z_]+\}\}", "", text)


# ---------------------------------------------------------------------------
# Agent
# ---------------------------------------------------------------------------
SCHEMA = """
CREATE TABLE IF NOT EXISTS tasks (
    pfad TEXT PRIMARY KEY,
    titel TEXT, projekt TEXT, start TEXT, ende TEXT,
    status TEXT, prioritaet TEXT, verantwortlich TEXT,
    checks_total INTEGER, checks_done INTEGER,
    erledigt_am TEXT, geaendert TEXT, aktiv INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS tagesuebersicht (
    datum TEXT, pfad TEXT, titel TEXT, projekt TEXT,
    kategorie TEXT, status TEXT, ende TEXT, prioritaet TEXT,
    PRIMARY KEY (datum, pfad)
);
CREATE TABLE IF NOT EXISTS lcm (
    pfad TEXT PRIMARY KEY,
    titel TEXT, kategorie TEXT, hersteller TEXT, produkt TEXT, version TEXT,
    projekt TEXT, standort TEXT, inbetriebnahme TEXT, end_of_support TEXT,
    end_of_life TEXT, status TEXT, verantwortlich TEXT, aktiv INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS notizen (
    pfad TEXT PRIMARY KEY,
    titel TEXT, typ TEXT, projekt TEXT, tags TEXT, kategorie TEXT,
    geaendert TEXT, inhalt TEXT, meta TEXT
);
CREATE TABLE IF NOT EXISTS plan_abgleich (schluessel TEXT PRIMARY KEY, erledigt INTEGER);
CREATE TABLE IF NOT EXISTS sync_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    zeitpunkt TEXT, art TEXT, dateien INTEGER, tasks_offen INTEGER,
    tasks_heute INTEGER, tasks_erledigt INTEGER, lcm INTEGER,
    dauer_ms INTEGER, fehler TEXT
);
CREATE INDEX IF NOT EXISTS ix_tasks_status ON tasks(status, aktiv);
CREATE INDEX IF NOT EXISTS ix_notizen_typ ON notizen(typ);
"""


class Agent:
    def __init__(self, cfg: dict | None = None):
        self.cfg = cfg or load_config()
        self._lock = threading.Lock()
        self._init_db()

    # --- Pfade -----------------------------------------------------------
    @property
    def vault(self) -> Path:
        return Path(self.cfg["vault_path"]).expanduser()

    @property
    def db_path(self) -> Path:
        p = Path(self.cfg["db_path"]).expanduser()
        return p if p.is_absolute() else BASE_DIR / p

    def vault_ok(self) -> bool:
        return self.vault.is_dir()

    def ordner(self, key: str) -> Path:
        name = self.cfg.get(key, "") or ""
        return self.vault / name if name else self.vault

    def rel(self, p: Path) -> str:
        return p.relative_to(self.vault).as_posix()

    def abs_in_vault(self, rel: str, root_ok: bool = False) -> Path:
        p = (self.vault / (rel or "")).resolve()
        v = self.vault.resolve()
        if root_ok and p == v:
            return p
        if v not in p.parents:
            raise ValueError("Pfad liegt ausserhalb des Vaults")
        return p

    def obsidian_link(self, rel: str) -> str:
        """Link, der die Notiz in Obsidian öffnet.

        Standard: absoluter Dateipfad (obsidian://open?path=...). Obsidian sucht dann
        selbst den Vault, der die Datei enthält. Das funktioniert auch, wenn der
        eingestellte Ordner nur ein Unterordner des Vaults ist oder der Vault in
        Obsidian anders heisst als der Ordner.
        Optional: "obsidian_vault_name" in config.json erzwingt die alte Variante
        vault=<Name>&file=<Pfad relativ zum Vault-Ordner>.
        """
        name = (self.cfg.get("obsidian_vault_name") or "").strip()
        if name:
            params = {"vault": name, "file": rel}
        else:
            params = {"path": str(self.vault / rel)}
        q = urllib.parse.urlencode(params, quote_via=urllib.parse.quote)
        return f"obsidian://open?{q}"

    # --- DB --------------------------------------------------------------
    def db(self) -> sqlite3.Connection:
        con = sqlite3.connect(self.db_path, timeout=30)
        con.row_factory = sqlite3.Row
        return con

    def _init_db(self):
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        with self.db() as con:
            con.executescript(SCHEMA)
            spalten = {r[1] for r in con.execute("PRAGMA table_info(notizen)")}
            if "meta" not in spalten:  # Migration von älteren Versionen
                con.execute("ALTER TABLE notizen ADD COLUMN meta TEXT")
            tspalten = {r[1] for r in con.execute("PRAGMA table_info(tasks)")}
            if "jourfixe" not in tspalten:
                con.execute("ALTER TABLE tasks ADD COLUMN jourfixe TEXT")

    # --- Grundstruktur ---------------------------------------------------
    def ensure_basics(self):
        """Legt Basisordner und Vorlagen an, falls sie fehlen (überschreibt nichts)."""
        if not self.vault_ok():
            raise FileNotFoundError(f"Vault nicht gefunden: {self.vault}")
        for key in ("projekt_ordner", "task_ordner", "wiki_ordner", "lcm_ordner",
                    "notiz_ordner", "vorlagen_ordner", "planer_ordner",
                    "devops_ordner", "ideen_ordner", "team_ordner", "jourfixe_ordner"):
            self.ordner(key).mkdir(parents=True, exist_ok=True)
        vdir = self.ordner("vorlagen_ordner")
        for v in VORLAGEN.values():
            f = vdir / v["datei"]
            if not f.exists():
                f.write_text(v["text"], encoding="utf-8")

    def vorlage_text(self, typ: str) -> str:
        v = VORLAGEN[typ]
        f = self.ordner("vorlagen_ordner") / v["datei"]
        if f.exists():
            return f.read_text(encoding="utf-8")
        return v["text"]

    def _unique(self, path: Path) -> Path:
        if not path.exists():
            return path
        i = 2
        while True:
            cand = path.with_name(f"{path.stem}_{i}{path.suffix}")
            if not cand.exists():
                return cand
            i += 1

    # --- Projekte ----------------------------------------------------------
    def projekt_struktur(self) -> dict[str, str]:
        """Standardordner + eigene Ordner aus der Konfiguration, nach Name sortiert."""
        s = dict(PROJEKT_STRUKTUR)
        s.update(self.cfg.get("eigene_projekt_ordner") or {})
        return dict(sorted(s.items(), key=lambda kv: kv[0].lower()))

    def _readme_devops(self, d: Path, projekt: str, zweck: str) -> str:
        devops = self.cfg.get("devops_ordner") or "DevOps"
        wo = f'projekt = "{projekt}"' if projekt else "true"
        return f"""---
typ: readme
projekt: {fm_value(projekt)}
ordner: {fm_value(d.name)}
erstellt: {dt.date.today().isoformat()}
tags: [readme, devops]
---
# DevOps – {projekt or d.name}

## Zweck dieses Ordners
{zweck}

Hier liegt alles, was zum **Bauen, Ausliefern und Betreiben** der Systeme dieses Projekts gehört.
Die zentrale Übersicht aller DevOps-Einträge (mit Status pro Umgebung) gibt es im Obsidian-Agent unter **DevOps**.

## Empfohlene Ablage
| Unterordner | Inhalt |
|---|---|
| `Pipelines/` | Build- und Release-Pipelines (Azure DevOps, GitHub Actions, GitLab CI), Trigger, Variablen |
| `Deployments/` | Deployment-Protokolle, Release Notes, Rollback-Pläne |
| `Umgebungen/` | Dev, Test, Staging, Prod: Server, URLs, Zugänge (ohne Passwörter!), Unterschiede |
| `Skripte/` | PowerShell, Bash, Python, mit Zweck, Parametern und Aufruf |
| `Repositories/` | Repo-Links, Branch-Strategie, Berechtigungen |
| `Monitoring/` | Checks, Alarme, Dashboards, Eskalation |
| `Infrastruktur/` | IaC (Terraform, Bicep, Ansible), Netz- und Cloud-Ressourcen |

> Unterordner legst du im Obsidian-Agent unter **Ordner** an oder direkt in Obsidian.
> Neue Notizen aus der Vorlage *DevOps-Eintrag* erstellst du unter **Aus Vorlage**.

## Umgebungen
| Umgebung | URL / Server | Zweck | Verantwortlich |
|---|---|---|---|
| Dev | | Entwicklung | |
| Test | | Abnahme / Tests | |
| Staging | | Produktionsnah | |
| Prod | | Produktion | |

## Repositories
| Repository | Link | Haupt-Branch | Pipeline |
|---|---|---|---|
| | | main | |

## Konventionen
- Keine Passwörter oder Secrets in Notizen. Nur den Ort im Passwort-Tresor angeben.
- Jede Änderung an Prod hat einen Change (Vorlage *Change*, Ordner `04_Betrieb_und_Wartung`).
- Skripte immer mit Zweck, Parametern und Beispielaufruf dokumentieren.

## DevOps-Einträge dieses Projekts (benötigt Community-Plugin Dataview)
```dataview
TABLE kategorie, umgebung, status, repository, verantwortlich
FROM "{devops}"
WHERE {wo}
SORT kategorie ASC
```

## Notizen in diesem Ordner
```dataview
LIST
FROM "{self.rel(d)}"
WHERE file.name != this.file.name
SORT file.mtime DESC
```
"""

    def _readme_schreiben(self, d: Path, projekt: str, zweck: str) -> None:
        readme = d / f"readme_{d.name}.md"
        if readme.exists():
            return
        if d.name == "07_DevOps":
            readme.write_text(self._readme_devops(d, projekt, zweck or PROJEKT_STRUKTUR["07_DevOps"]), encoding="utf-8")
            return
        teile = d.name.split("_", 1)
        titel = (teile[1] if len(teile) == 2 and teile[0].isdigit() else d.name).replace("_", " ")
        kopf = f"# {titel} – {projekt}" if projekt else f"# {titel}"
        readme.write_text(
            f"---\ntyp: readme\nprojekt: {fm_value(projekt)}\nordner: {fm_value(d.name)}\n"
            f"erstellt: {dt.date.today().isoformat()}\ntags: [readme]\n---\n"
            f"{kopf}\n\n## Zweck dieses Ordners\n{zweck or '-'}\n\n"
            f"## Inhalt / Übersicht\n- \n\n## Hinweise\n- \n",
            encoding="utf-8")

    def projekte(self) -> list[dict]:
        root = self.ordner("projekt_ordner")
        if not root.is_dir():
            return []
        result = []
        struktur = self.projekt_struktur()
        with self.db() as con:
            for d in sorted(root.iterdir(), key=lambda p: p.name.lower()):
                if not d.is_dir() or d.name.startswith((".", "_")):
                    continue
                if not self.cfg.get("projekt_ordner") and not (d / "01_Vertraege_und_SLA").is_dir():
                    continue  # bei Root-Ablage nur echte Projektordner zeigen
                offen = con.execute(
                    "SELECT COUNT(*) FROM tasks WHERE aktiv=1 AND status!='erledigt' AND projekt=?",
                    (d.name,)).fetchone()[0]
                result.append({"name": d.name, "pfad": self.rel(d), "offen": offen,
                               "vollstaendig": all((d / o).is_dir() for o in struktur)})
        return result

    def projekt_unterordner(self, projekt: str, max_tiefe: int = 3) -> list[dict]:
        """Alle Unterordner eines Projekts, direkt aus dem Vault gelesen.
        Ordner, die von Hand in Obsidian angelegt wurden, sind damit sofort dabei."""
        root = self.ordner("projekt_ordner") / safe_name(projekt)
        if not projekt or not root.is_dir():
            return []
        out: list[dict] = []

        def walk(d: Path, tiefe: int):
            try:
                kinder = sorted((k for k in d.iterdir() if k.is_dir()), key=lambda p: p.name.lower())
            except OSError:
                return
            for k in kinder:
                if k.name.startswith("."):
                    continue
                out.append({"pfad": k.relative_to(root).as_posix(), "name": k.name, "tiefe": tiefe})
                if tiefe + 1 < max_tiefe:
                    walk(k, tiefe + 1)
        walk(root, 0)
        return out

    def projekte_ergaenzen(self) -> tuple[int, int]:
        """Fehlende Standardordner (inkl. readme) in allen Projekten anlegen.
        Rückgabe: (ergänzte Projekte, neue Ordner). Bestehendes wird nie überschrieben."""
        n_proj = n_ord = 0
        for p in self.projekte():
            if p["vollstaendig"]:
                continue
            root = self.ordner("projekt_ordner") / p["name"]
            fehlend = [o for o in self.projekt_struktur() if not (root / o).is_dir()]
            self.projekt_anlegen(p["name"])
            n_proj += 1
            n_ord += len(fehlend)
        return n_proj, n_ord

    def projekt_anlegen(self, name: str, kunde: str = "", beschreibung: str = "") -> Path:
        self.ensure_basics()
        name = safe_name(name)
        if not name:
            raise ValueError("Bitte einen Projektnamen eingeben.")
        root = self.ordner("projekt_ordner") / name
        neu = not root.exists()
        root.mkdir(parents=True, exist_ok=True)
        heute = dt.date.today().isoformat()
        struktur = self.projekt_struktur()
        for ordner, zweck in struktur.items():
            d = root / ordner
            d.mkdir(exist_ok=True)
            self._readme_schreiben(d, name, zweck)
        uebersicht = root / f"_Projekt_{safe_name(name, True)}.md"
        if uebersicht.exists():  # neue Standardordner in der Übersicht unter "## Struktur" nachtragen
            text = uebersicht.read_text(encoding="utf-8")
            fehlend = [o for o in struktur if f"/{o}/readme_{o}|" not in text]
            if fehlend and "## Struktur\n" in text:
                neu = "".join(f"- [[{self.rel(root / o / f'readme_{o}')}|{o}]]\n" for o in fehlend)
                kopf, rest = text.split("## Struktur\n", 1)
                block_ende = rest.find("\n\n")
                block_ende = len(rest) if block_ende < 0 else block_ende + 1
                zeilen = [z for z in (rest[:block_ende] + neu).split("\n") if z.strip()]
                if all(z.startswith("- [[") for z in zeilen):  # reine Linkliste: nach Ordnername sortieren
                    zeilen.sort(key=lambda z: z.rsplit("|", 1)[-1].lower())
                block = "\n".join(zeilen) + "\n"
                uebersicht.write_text(kopf + "## Struktur\n" + block + rest[block_ende:], encoding="utf-8")
        else:
            links = "\n".join(
                f"- [[{self.rel(root / o / f'readme_{o}')}|{o}]]" for o in struktur)
            uebersicht.write_text(
                f"---\ntyp: projekt\ntitel: {fm_value(name)}\nprojekt: {fm_value(name)}\n"
                f"kunde: {fm_value(kunde)}\nstatus: aktiv\nerstellt: {heute}\ntags: [projekt]\n---\n"
                f"# Projekt: {name}\n\n{beschreibung}\n\n## Struktur\n{links}\n\n"
                f"## Offene Tasks (benötigt Community-Plugin Dataview)\n"
                f"```dataview\nTABLE start, ende, status, prioritaet\nFROM \"{self.rel(root)}\"\n"
                f"WHERE typ = \"task\" AND status != \"erledigt\"\nSORT ende ASC\n```\n",
                encoding="utf-8")
        return root

    # --- Eigene Ordner -------------------------------------------------------
    def ordner_liste(self, max_tiefe: int = 4) -> list[dict]:
        """Alle Ordner im Vault (ohne versteckte), für Auswahl und Baumansicht."""
        out = []
        skip = {".obsidian", ".trash", ".git", "node_modules"}

        def walk(d: Path, tiefe: int):
            try:
                kinder = sorted((k for k in d.iterdir() if k.is_dir()), key=lambda p: p.name.lower())
            except OSError:
                return
            for k in kinder:
                if k.name.startswith(".") or k.name in skip:
                    continue
                anzahl = sum(1 for f in k.iterdir() if f.is_file() and f.suffix == ".md")
                out.append({"pfad": self.rel(k), "name": k.name, "tiefe": tiefe, "notizen": anzahl,
                            "link": self.obsidian_link(self.rel(k))})
                if tiefe < max_tiefe:
                    walk(k, tiefe + 1)
        if self.vault_ok():
            walk(self.vault, 0)
        return out

    def ordner_anlegen(self, eltern: str, name: str, zweck: str = "", readme: bool = True) -> Path:
        """Eigenen Ordner irgendwo im Vault anlegen (optional mit readme_<Name>.md)."""
        if not self.vault_ok():
            raise FileNotFoundError(f"Vault nicht gefunden: {self.vault}")
        name = safe_name(name)
        if not name:
            raise ValueError("Bitte einen Ordnernamen eingeben.")
        basis = self.abs_in_vault(eltern, root_ok=True)
        if not basis.is_dir():
            raise ValueError(f"Übergeordneter Ordner existiert nicht: {eltern}")
        d = basis / name
        if d.exists():
            raise ValueError(f"Ordner existiert bereits: {self.rel(d)}")
        d.mkdir(parents=True)
        if readme:
            self._readme_schreiben(d, self._projekt_aus_pfad(self.rel(d) + "/x.md"), zweck)
        return d

    def struktur_ordner_hinzufuegen(self, name: str, zweck: str = "", bestehende: bool = False) -> int:
        """Eigenen Ordner zur Projekt-Standardstruktur hinzufügen.
        bestehende=True legt ihn auch in allen vorhandenen Projekten an. Rückgabe: Anzahl ergänzter Projekte."""
        name = safe_name(name, underscore=True)
        if not name:
            raise ValueError("Bitte einen Ordnernamen eingeben.")
        if name in PROJEKT_STRUKTUR:
            raise ValueError(f"'{name}' ist bereits ein Standardordner.")
        eigene = dict(self.cfg.get("eigene_projekt_ordner") or {})
        eigene[name] = zweck.strip()
        self.cfg["eigene_projekt_ordner"] = eigene
        save_config(self.cfg)
        n = 0
        if bestehende:
            for p in self.projekte():
                d = self.ordner("projekt_ordner") / p["name"] / name
                if not d.exists():
                    d.mkdir(parents=True)
                    self._readme_schreiben(d, p["name"], zweck)
                    n += 1
        return n

    def struktur_ordner_entfernen(self, name: str) -> None:
        """Entfernt einen eigenen Ordner aus der Vorlage. Bestehende Ordner im Vault bleiben unangetastet."""
        eigene = dict(self.cfg.get("eigene_projekt_ordner") or {})
        if name not in eigene:
            raise ValueError("Nur eigene Ordner können entfernt werden.")
        del eigene[name]
        self.cfg["eigene_projekt_ordner"] = eigene
        save_config(self.cfg)

    # --- Tasks -------------------------------------------------------------
    def task_anlegen(self, titel: str, start: str = "", ende: str = "", projekt: str = "",
                     prioritaet: str = "mittel", verantwortlich: str = "",
                     beschreibung: str = "", checkliste: str = "",
                     ordner: Path | None = None, extra: dict | None = None, unterordner: str = "") -> Path:
        """Legt Task_<Titel>.md an. ordner: abweichender Zielordner (z.B. Jour Fixe),
        extra: zusätzliche Frontmatter-Felder (z.B. jourfixe)."""
        self.ensure_basics()
        if not titel.strip():
            raise ValueError("Titel fehlt.")
        start_d = parse_date(start) or dt.date.today()
        ende_d = parse_date(ende) or start_d
        if ende_d < start_d:
            raise ValueError("Enddatum liegt vor dem Startdatum.")
        if ordner is not None:
            ziel = ordner
            ziel.mkdir(parents=True, exist_ok=True)
        elif projekt:
            ziel = self.ordner("projekt_ordner") / safe_name(projekt)
            if not ziel.is_dir():
                raise ValueError(f"Projekt '{projekt}' existiert nicht.")
            unterordner = (unterordner or "").strip().strip("/\\")
            if unterordner:
                proj_root = ziel.resolve()
                ziel = (ziel / unterordner).resolve()
                if proj_root not in ziel.parents:
                    raise ValueError("Der gewählte Ordner liegt nicht im Projekt.")
                if not ziel.is_dir():
                    raise ValueError(f"Ordner '{unterordner}' gibt es im Projekt '{projekt}' nicht (mehr). "
                                     "Bitte Seite neu laden.")
        else:
            ziel = self.ordner("task_ordner")
        datei = self._unique(ziel / f"Task_{safe_name(titel, True)}.md")
        checks = "\n".join(f"- [ ] {l.strip()}" for l in checkliste.splitlines() if l.strip()) or "- [ ] "
        text = render_vorlage(self.vorlage_text("task"), {
            "title": titel.strip(), "date": dt.date.today().isoformat(), "projekt": projekt,
            "start": iso(start_d), "ende": iso(ende_d), "prioritaet": prioritaet,
            "verantwortlich": verantwortlich, "beschreibung": beschreibung, "checkliste": checks,
        })
        # Pflichtfelder absichern, auch wenn die Vorlage in Obsidian verändert wurde
        text = set_frontmatter(text, {"typ": "task", "titel": titel.strip(), "start": iso(start_d),
                                      "ende": iso(ende_d), "status": "offen", "projekt": projekt,
                                      "prioritaet": prioritaet, "verantwortlich": verantwortlich,
                                      **(extra or {})})
        datei.write_text(text, encoding="utf-8")
        with self.db() as con:
            self._index_file(con, datei, dt.date.today())
        return datei

    def task_status_setzen(self, rel: str, status: str) -> None:
        if status not in TASK_STATUS:
            raise ValueError("Ungültiger Status")
        p = self.abs_in_vault(rel)
        text = p.read_text(encoding="utf-8")
        werte = {"status": status}
        werte["erledigt_am"] = dt.date.today().isoformat() if status == "erledigt" else ""
        p.write_text(set_frontmatter(text, werte), encoding="utf-8")
        with self.db() as con:
            self._index_file(con, p, dt.date.today())
            self._tagesuebersicht(con, dt.date.today())
        plan = WIKILINK_RE.fullmatch((parse_frontmatter(text)[0].get("plan") or "").strip())
        if plan and (self.vault / (plan.group(1) + ".md")).is_file():  # Häkchen im Projektplan nachführen
            self.plan_abgleichen(plan.group(1) + ".md")

    def task_verschieben(self, rel: str, tage: int) -> None:
        """Start/Ende um n Tage verschieben (z.B. 'auf morgen')."""
        p = self.abs_in_vault(rel)
        text = p.read_text(encoding="utf-8")
        fm, _ = parse_frontmatter(text)
        heute = dt.date.today()
        start = parse_date(fm.get("start")) or heute
        ende = parse_date(fm.get("ende")) or start
        dauer = (ende - start).days
        neu_start = max(start, heute) + dt.timedelta(days=tage)
        p.write_text(set_frontmatter(text, {"start": iso(neu_start),
                                            "ende": iso(neu_start + dt.timedelta(days=dauer))}),
                     encoding="utf-8")
        with self.db() as con:
            self._index_file(con, p, heute)
            self._tagesuebersicht(con, heute)

    def tasks(self, heute: dt.date | None = None, projekt: str = "") -> dict[str, list[dict]]:
        heute = heute or dt.date.today()
        sql = "SELECT * FROM tasks WHERE aktiv=1"
        args: list = []
        if projekt:
            sql += " AND projekt=?"
            args.append(projekt)
        gruppen = {k: [] for k in ("heute", "ueberfaellig", "geplant", "ohne_datum", "erledigt")}
        with self.db() as con:
            for r in con.execute(sql, args):
                t = dict(r)
                t["kategorie"] = task_kategorie(t, heute)
                t["link"] = self.obsidian_link(t["pfad"])
                e = parse_date(t["ende"])
                t["rest_tage"] = (e - heute).days if e else None
                gruppen[t["kategorie"]].append(t)

        def key(t):
            return (PRIO_ORDER.get((t["prioritaet"] or "").lower(), 1), t["ende"] or "9999", t["titel"].lower())
        for k in ("heute", "ueberfaellig", "ohne_datum"):
            gruppen[k].sort(key=key)
        gruppen["geplant"].sort(key=lambda t: (t["start"] or "9999", key(t)))
        gruppen["erledigt"].sort(key=lambda t: t["erledigt_am"] or "", reverse=True)
        return gruppen

    # --- Wiki ----------------------------------------------------------------
    def wiki_anlegen(self, titel: str, kategorie: str = "", tags: str = "", inhalt: str = "") -> Path:
        self.ensure_basics()
        if not titel.strip():
            raise ValueError("Titel fehlt.")
        kategorie = self._wiki_kat_pfad(kategorie)
        ziel = self.ordner("wiki_ordner")
        if kategorie:
            ziel = ziel / kategorie
        ziel.mkdir(parents=True, exist_ok=True)
        datei = self._unique(ziel / f"{safe_name(titel)}.md")
        tags_clean = ", ".join(["wiki"] + [t.strip().lstrip("#") for t in tags.split(",") if t.strip()])
        text = render_vorlage(self.vorlage_text("wiki"), {
            "title": titel.strip(), "date": dt.date.today().isoformat(),
            "kategorie": kategorie, "tags": tags_clean, "inhalt": inhalt,
        })
        text = set_frontmatter(text, {"typ": "wiki", "titel": titel.strip()})
        datei.write_text(text, encoding="utf-8")
        with self.db() as con:
            self._index_file(con, datei, dt.date.today())
        self._wiki_index()
        return datei

    @staticmethod
    def _wiki_kat_pfad(kategorie: str) -> str:
        """'Netzwerk / Firewall' -> 'Netzwerk/Firewall' (Unterkategorien mit '/')."""
        teile = [safe_name(t) for t in re.split(r"[\\/]", kategorie or "")]
        return "/".join(t for t in teile if t)

    def wiki_kategorien(self) -> list[dict]:
        """Alle Kategorien = Unterordner des Wiki-Ordners (auch leere), mit Anzahl Artikel."""
        wdir = self.ordner("wiki_ordner")
        if not wdir.is_dir():
            return []
        out = []
        for d in sorted((x for x in wdir.rglob("*") if x.is_dir()), key=lambda x: x.relative_to(wdir).as_posix().lower()):
            rel = d.relative_to(wdir).as_posix()
            if any(t.startswith(".") for t in rel.split("/")):
                continue
            out.append({"name": rel, "tiefe": rel.count("/"),
                        "artikel": sum(1 for f in d.glob("*.md") if not f.name.startswith(("_", "readme_"))),
                        "link": self.obsidian_link(self.rel(d))})
        return out

    def wiki_kategorie_anlegen(self, name: str, eltern: str = "") -> Path:
        """Neue (auch leere) Wiki-Kategorie = Unterordner im Wiki anlegen."""
        self.ensure_basics()
        name = self._wiki_kat_pfad(name)
        if not name:
            raise ValueError("Bitte einen Namen für die Kategorie eingeben.")
        eltern = self._wiki_kat_pfad(eltern)
        pfad = f"{eltern}/{name}" if eltern else name
        d = self.ordner("wiki_ordner") / pfad
        if d.exists():
            raise ValueError(f"Kategorie existiert bereits: {pfad}")
        d.mkdir(parents=True)
        self._wiki_index()
        return d

    def wiki_artikel(self) -> list[dict]:
        with self.db() as con:
            rows = con.execute("SELECT pfad, titel, kategorie, tags, geaendert FROM notizen "
                               "WHERE typ='wiki' ORDER BY kategorie, titel").fetchall()
        return [dict(r, link=self.obsidian_link(r["pfad"])) for r in rows]

    def _wiki_index(self):
        artikel = self.wiki_artikel()
        wdir = self.ordner("wiki_ordner")
        if not wdir.is_dir():
            return
        zeilen = ["---", "typ: index", "---", "# Wiki – Inhaltsverzeichnis",
                  "> Automatisch erzeugt vom Obsidian-Agent.", ""]
        aktuelle = None
        for a in artikel:
            if a["pfad"].endswith("_Index.md"):
                continue
            kat = a["kategorie"] or "Allgemein"
            if kat != aktuelle:
                zeilen += ["", f"## {kat}"]
                aktuelle = kat
            zeilen.append(f"- [[{a['pfad'][:-3]}|{a['titel']}]]")
        (wdir / "_Index.md").write_text("\n".join(zeilen) + "\n", encoding="utf-8")

    # --- LifeCycle ---------------------------------------------------------
    def lcm_anlegen(self, daten: dict) -> Path:
        self.ensure_basics()
        titel = (daten.get("titel") or "").strip()
        if not titel:
            raise ValueError("Bezeichnung fehlt.")
        kat = daten.get("kategorie") or "Hardware"
        ziel = self.ordner("lcm_ordner") / safe_name(kat)
        ziel.mkdir(parents=True, exist_ok=True)
        datei = self._unique(ziel / f"LCM_{safe_name(titel, True)}.md")
        werte = {k: (daten.get(k) or "").strip() for k in (
            "hersteller", "produkt", "version", "projekt", "standort", "verantwortlich", "beschreibung")}
        for k in ("inbetriebnahme", "end_of_support", "end_of_life"):
            werte[k] = iso(parse_date(daten.get(k))) or ""
        werte.update({"title": titel, "date": dt.date.today().isoformat(), "kategorie": kat,
                      "status": daten.get("status") or "Betrieb"})
        text = render_vorlage(self.vorlage_text("lcm"), werte)
        text = set_frontmatter(text, {"typ": "lcm", "titel": titel})
        datei.write_text(text, encoding="utf-8")
        with self.db() as con:
            self._index_file(con, datei, dt.date.today())
        return datei

    def lcm_eintraege(self, heute: dt.date | None = None) -> list[dict]:
        heute = heute or dt.date.today()
        warn = int(self.cfg.get("lcm_warnung_tage", 90))
        with self.db() as con:
            rows = [dict(r) for r in con.execute("SELECT * FROM lcm WHERE aktiv=1")]
        order = {"rot": 0, "orange": 1, "gelb": 2, "gruen": 3, "grau": 4}
        for r in rows:
            r["ampel"] = lcm_ampel(r, heute, warn)
            r["link"] = self.obsidian_link(r["pfad"])
        rows.sort(key=lambda r: (order[r["ampel"]["farbe"]],
                                 r["ampel"]["tage"] if r["ampel"]["tage"] is not None else 99999))
        return rows

    # --- Notizen aus Vorlagen ----------------------------------------------
    def notiz_anlegen(self, typ: str, titel: str, projekt: str = "") -> Path:
        self.ensure_basics()
        if typ not in NOTIZ_TYPEN:
            raise ValueError("Unbekannter Notiztyp")
        if not titel.strip():
            raise ValueError("Titel fehlt.")
        v = VORLAGEN[typ]
        heute = dt.date.today()
        if projekt:
            ziel = self.ordner("projekt_ordner") / safe_name(projekt) / v["ordner"]
            if not ziel.is_dir():  # z.B. 07_DevOps in älteren Projekten: Ordner samt readme anlegen
                ziel.mkdir(parents=True, exist_ok=True)
                self._readme_schreiben(ziel, projekt, self.projekt_struktur().get(v["ordner"], ""))
        elif typ == "devops_doku":
            ziel = self.ordner("devops_ordner") / "Dokumentation"
        else:
            ziel = self.ordner("notiz_ordner") / v["label"].split(" ")[0]
        ziel.mkdir(parents=True, exist_ok=True)
        name = v["dateiname"].format(date=heute.isoformat(), monat=heute.strftime("%Y-%m"),
                                     titel=safe_name(titel), titel_=safe_name(titel, True))
        datei = self._unique(ziel / f"{name}.md")
        text = render_vorlage(self.vorlage_text(typ), {
            "title": titel.strip(), "date": heute.isoformat(), "projekt": projekt})
        datei.write_text(text, encoding="utf-8")
        with self.db() as con:
            self._index_file(con, datei, heute)
        return datei

    # --- Aus Vorlage -----------------------------------------------------------
    VORLAGE_ZIEL = {"devops": "07_DevOps", "jourfixe": "10_Korrespondenz", "task": "", "idee": "06_Projekte"}

    def vorlagen_liste(self) -> list[dict]:
        """Alle .md-Dateien im Vorlagen-Ordner (auch selbst erstellte), mit vorgeschlagenem Zielordner.
        Eigene Vorlagen können im Frontmatter 'zielordner: 04_Betrieb_und_Wartung' setzen."""
        self.ensure_basics()
        vdir = self.ordner("vorlagen_ordner")
        bekannt = {v["datei"].lower(): (k, v) for k, v in VORLAGEN.items()}
        out = []
        for f in sorted(vdir.rglob("*.md"), key=lambda p: p.name.lower()):
            fm, _ = parse_frontmatter(f.read_text(encoding="utf-8", errors="replace"))
            key, v = bekannt.get(f.name.lower(), (None, None))
            typ = (fm.get("typ") or key or "").lower()
            ziel = fm.get("zielordner") or (v or {}).get("ordner") or self.VORLAGE_ZIEL.get(typ, "") or ""
            if typ == "projektprotokoll":  # Protokolle folgen immer der Einstellung (Standard 06_Projekte)
                ziel = (self.cfg.get("protokoll_ordner") or "06_Projekte").strip("/\\")
            name = (v or {}).get("label") or re.sub(r"^Vorlage[_ -]*", "", f.stem).replace("_", " ")
            out.append({"datei": f.relative_to(vdir).as_posix(), "name": name, "typ": typ,
                        "ziel": ziel, "eigen": v is None, "link": self.obsidian_link(self.rel(f))})
        return out

    def aus_vorlage_anlegen(self, datei: str, titel: str, projekt: str = "", unterordner: str = "") -> Path:
        """Neue Notiz aus einer beliebigen Vorlage in einem Projekt(-Unterordner) anlegen."""
        self.ensure_basics()
        titel = titel.strip()
        if not titel:
            raise ValueError("Titel fehlt.")
        vdir = self.ordner("vorlagen_ordner").resolve()
        vorlage = (vdir / datei).resolve()
        if vdir not in vorlage.parents or not vorlage.is_file():
            raise ValueError("Vorlage nicht gefunden. Bitte Seite neu laden.")
        heute = dt.date.today()
        if projekt:
            root = (self.ordner("projekt_ordner") / safe_name(projekt)).resolve()
            if not root.is_dir():
                raise ValueError(f"Projekt '{projekt}' existiert nicht.")
            ziel = (root / unterordner.strip().strip("/\\")).resolve() if unterordner.strip() else root
            if ziel != root and root not in ziel.parents:
                raise ValueError("Der gewählte Ordner liegt nicht im Projekt.")
            if not ziel.is_dir():
                raise ValueError(f"Ordner '{unterordner}' gibt es im Projekt nicht (mehr). Bitte Seite neu laden.")
        else:
            ziel = self.ordner("notiz_ordner")
            ziel.mkdir(parents=True, exist_ok=True)
        text = vorlage.read_text(encoding="utf-8")
        fm, _ = parse_frontmatter(text)
        typ = (fm.get("typ") or fm.get("type") or "").lower()
        praefix = {"task": "Task_", "lcm": "LCM_"}.get(typ, "")
        datei_neu = self._unique(ziel / f"{praefix}{safe_name(titel, bool(praefix))}.md")
        uebersicht = f"_Projekt_{safe_name(projekt, True)}"
        text = render_vorlage(text, {"title": titel, "date": heute.isoformat(), "projekt": projekt,
                                     "projekt_link": f"[[{uebersicht}|{projekt}]]" if projekt else "",
                                     "datum_zeit": heute.isoformat(),
                                     "start": heute.isoformat(), "ende": heute.isoformat(),
                                     "datum": heute.isoformat(), "prioritaet": "mittel",
                                     "status": "offen" if typ == "projektprotokoll" else ""})
        werte = {"titel": titel}
        if projekt:
            werte["projekt"] = f"[[{uebersicht}|{projekt}]]" if typ == "projektprotokoll" else projekt
        if typ == "task":
            werte.update({"status": "offen", "start": heute.isoformat(), "ende": heute.isoformat()})
        text = set_frontmatter(text, werte)
        # Vorlagen-Hilfsfelder nicht in die neue Notiz übernehmen
        text = re.sub(r"(?m)^zielordner:.*\n", "", text, count=1)
        datei_neu.write_text(text, encoding="utf-8")
        with self.db() as con:
            self._index_file(con, datei_neu, heute)
        return datei_neu

    def letzte_notizen(self, limit: int = 15) -> list[dict]:
        with self.db() as con:
            rows = con.execute("SELECT pfad, titel, typ, projekt, geaendert FROM notizen "
                               "WHERE typ NOT IN ('readme','index','planer','vorlage') "
                               "ORDER BY geaendert DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r, link=self.obsidian_link(r["pfad"])) for r in rows]

    # --- DevOps / Ideenbox / Team ---------------------------------------------
    def eintraege(self, typ: str) -> list[dict]:
        """Alle Notizen eines Typs inkl. Frontmatter-Feldern (aus dem letzten Sync)."""
        with self.db() as con:
            rows = con.execute("SELECT pfad, titel, projekt, kategorie, geaendert, meta FROM notizen "
                               "WHERE typ=? ORDER BY titel COLLATE NOCASE", (typ,)).fetchall()
        out = []
        for r in rows:
            d = json.loads(r["meta"] or "{}")
            d.update({k: r[k] for k in ("pfad", "titel", "projekt", "geaendert")})
            d["kategorie"] = d.get("kategorie") or r["kategorie"] or ""
            d["link"] = self.obsidian_link(r["pfad"])
            out.append(d)
        return out

    def _eintrag_datei(self, ordner_key: str, unterordner: str, dateiname: str) -> Path:
        self.ensure_basics()
        ziel = self.ordner(ordner_key)
        if unterordner:
            ziel = ziel / safe_name(unterordner)
        ziel.mkdir(parents=True, exist_ok=True)
        return self._unique(ziel / f"{dateiname}.md")

    def _eintrag_schreiben(self, typ: str, datei: Path, werte: dict) -> Path:
        werte = {k: ("" if v is None else str(v).strip()) for k, v in werte.items()}
        werte.setdefault("date", dt.date.today().isoformat())
        text = render_vorlage(self.vorlage_text(typ), werte)
        text = set_frontmatter(text, {"typ": typ, "titel": werte["title"]})
        datei.write_text(text, encoding="utf-8")
        with self.db() as con:
            self._index_file(con, datei, dt.date.today())
        return datei

    def devops_anlegen(self, d: dict) -> Path:
        titel = (d.get("titel") or "").strip()
        if not titel:
            raise ValueError("Titel fehlt.")
        kat = d.get("kategorie") or "Pipeline"
        datei = self._eintrag_datei("devops_ordner", kat, safe_name(titel))
        return self._eintrag_schreiben("devops", datei, {
            "title": titel, "kategorie": kat, "projekt": d.get("projekt"), "umgebung": d.get("umgebung"),
            "status": d.get("status") or "aktiv", "repository": d.get("repository"),
            "verantwortlich": d.get("verantwortlich"), "beschreibung": d.get("beschreibung")})

    def idee_anlegen(self, d: dict) -> Path:
        titel = (d.get("titel") or "").strip()
        if not titel:
            raise ValueError("Titel fehlt.")
        heute = dt.date.today().isoformat()
        datei = self._eintrag_datei("ideen_ordner", "", f"Idee_{heute}_{safe_name(titel, True)}")
        return self._eintrag_schreiben("idee", datei, {
            "title": titel, "kategorie": d.get("kategorie"), "projekt": d.get("projekt"),
            "eingereicht_von": d.get("eingereicht_von"), "nutzen": d.get("nutzen") or "mittel",
            "aufwand": d.get("aufwand") or "mittel", "problem": d.get("problem"),
            "beschreibung": d.get("beschreibung")})

    def person_anlegen(self, d: dict) -> Path:
        name = (d.get("titel") or "").strip()
        if not name:
            raise ValueError("Name fehlt.")
        datei = self.ordner("team_ordner") / f"{safe_name(name)}.md"
        if datei.exists():
            raise ValueError(f"Teammitglied existiert bereits: {self.rel(datei)}")
        datei = self._eintrag_datei("team_ordner", "", safe_name(name))
        return self._eintrag_schreiben("person", datei, {
            "title": name, **{k: d.get(k) for k in ("kuerzel", "rolle", "team", "email", "telefon",
                                                     "standort", "vertretung", "skills")}})

    FELD_ERLAUBT = {"idee": {"status"}, "devops": {"status"}, "projektprotokoll": {"status"}}

    def feld_setzen(self, rel: str, feld: str, wert: str) -> None:
        p = self.abs_in_vault(rel)
        fm, _ = parse_frontmatter(p.read_text(encoding="utf-8"))
        typ = (fm.get("typ") or fm.get("type") or "").lower()
        if feld not in self.FELD_ERLAUBT.get(typ, set()):
            raise ValueError("Dieses Feld kann hier nicht geändert werden.")
        p.write_text(set_frontmatter(p.read_text(encoding="utf-8"), {feld: wert}), encoding="utf-8")
        with self.db() as con:
            self._index_file(con, p, dt.date.today())

    def idee_zu_task(self, rel: str, start: str = "", ende: str = "", verantwortlich: str = "") -> Path:
        """Erstellt aus einer Idee einen Task und verknüpft beide."""
        p = self.abs_in_vault(rel)
        text = p.read_text(encoding="utf-8")
        fm, _ = parse_frontmatter(text)
        titel = fm.get("titel") or p.stem
        projekt = fm.get("projekt") or ""
        if projekt and not (self.ordner("projekt_ordner") / safe_name(projekt)).is_dir():
            projekt = ""
        task = self.task_anlegen(titel, start, ende, projekt, "mittel", verantwortlich,
                                 f"Aus der Ideenbox: [[{rel[:-3]}|{titel}]]")
        p.write_text(set_frontmatter(text, {"status": "angenommen", "task": f"[[{self.rel(task)[:-3]}]]"}),
                     encoding="utf-8")
        with self.db() as con:
            self._index_file(con, p, dt.date.today())
        return task

    def team(self) -> list[dict]:
        """Teammitglieder inkl. offener Tasks (Zuordnung über Feld 'verantwortlich': Name oder Kürzel)."""
        personen = self.eintraege("person")
        g = self.tasks()
        offen = [t for k in ("ueberfaellig", "heute", "geplant", "ohne_datum") for t in g[k]]
        for p in personen:
            schluessel = {x.lower() for x in (p["titel"], p.get("kuerzel") or "") if x}
            p["tasks"] = [t for t in offen
                          if schluessel & {x.strip() for x in re.split(r"[,;/&]", (t["verantwortlich"] or "").lower())}]
            p["ueberfaellig"] = sum(t["kategorie"] == "ueberfaellig" for t in p["tasks"])
        return personen

    # --- Projektprotokoll -------------------------------------------------------
    @staticmethod
    def _zeilen(text: str, praefix: str = "- ") -> str:
        z = [l.strip().lstrip("-*• ").strip() for l in (text or "").splitlines()]
        z = [l for l in z if l]
        return "\n".join(praefix + l for l in z) if z else praefix.rstrip() + " "

    def _personen_links(self, namen: str) -> str:
        """'Marcel, AKE' -> '[[Marcel Luginbühl]], [[Anna Keller]]': Kürzel/Vornamen der Teammitglieder
        werden zum vollen Namen, damit der Link in Obsidian auf die Personenkarte zeigt."""
        team = self.eintraege("person")
        out = []
        for n in re.split(r"[,;]", namen or ""):
            n = link_name(n.strip())
            if not n:
                continue
            treffer = [p["titel"] for p in team if n.lower() in
                       {(p["titel"] or "").lower(), (p.get("kuerzel") or "").lower()}]
            if not treffer:  # eindeutiger Vorname
                treffer = [p["titel"] for p in team if (p["titel"] or "").lower().split(" ")[0] == n.lower()]
            out.append(f"[[{treffer[0] if len(treffer) == 1 else n}]]")
        return ", ".join(out)

    def protokoll_anlegen(self, d: dict, beschluesse: list[tuple] = (), aufgaben: list[tuple] = (),
                          als_tasks: bool = True) -> Path:
        """Projektprotokoll in <Projekt>/<protokoll_ordner> (Standard 06_Projekte) anlegen.
        Jede ausgefüllte Aufgabe wird zusätzlich als Task angelegt und im Protokoll verlinkt.
        beschluesse: [(text, verantwortlich, bis)], aufgaben: [(text, wer, faellig)]"""
        self.ensure_basics()
        projekt = (d.get("projekt") or "").strip()
        root = self.ordner("projekt_ordner") / safe_name(projekt)
        if not projekt or not root.is_dir():
            raise ValueError("Bitte ein Projekt wählen.")
        datum = parse_date(d.get("datum")) or dt.date.today()
        ziel = root / ((self.cfg.get("protokoll_ordner") or "06_Projekte").strip("/\\"))
        if not ziel.is_dir():
            ziel.mkdir(parents=True)
            self._readme_schreiben(ziel, projekt, self.projekt_struktur().get(ziel.name, ""))
        uebersicht = f"_Projekt_{safe_name(projekt, True)}"
        projekt_link = f"[[{uebersicht}|{projekt}]]" if (root / f"{uebersicht}.md").exists() else f"[[{projekt}]]"
        von, bis = (d.get("zeit_von") or "").strip(), (d.get("zeit_bis") or "").strip()
        zeit = f"{von}–{bis}" if von and bis else (von or bis)

        b_zeilen = []
        for text, wer, frist in beschluesse:
            if not (text or "").strip():
                continue
            zusatz = ", ".join(x for x in (f"verantwortlich: {self._personen_links(wer)}" if wer.strip() else "",
                                            f"bis {iso(parse_date(frist))}" if parse_date(frist) else "") if x)
            b_zeilen.append(f"- [ ] **Entscheidung:** {text.strip()}" + (f" *({zusatz})*" if zusatz else ""))
        a_zeilen = []
        for text, wer, frist in aufgaben:
            if not (text or "").strip():
                continue
            zeile = f"- [ ] {text.strip()}"
            if wer.strip():
                zeile += " " + " ".join("@" + w for w in self._personen_links(wer).split(", "))
            if parse_date(frist):
                zeile += f" 📅 {iso(parse_date(frist))}"
            a_zeilen.append(zeile)

        naechster = parse_date(d.get("naechster_termin"))
        text = render_vorlage(self.vorlage_text("projektprotokoll"), {
            "projekt": projekt, "projekt_link": projekt_link, "datum": datum.isoformat(),
            "date": datum.isoformat(), "title": f"Projektprotokoll {projekt} {datum.isoformat()}",
            "status": d.get("status") or "offen",
            "datum_zeit": datum.isoformat() + (f", {zeit}" if zeit else ""),
            "teilnehmer": self._personen_links(d.get("teilnehmer", "")),
            "moderation": self._personen_links(d.get("moderation", "")),
            "kurzfassung": self._zeilen(d.get("kurzfassung")), "agenda": self._zeilen(d.get("agenda")),
            "beschluesse": "\n".join(b_zeilen) or "- [ ] **Entscheidung:** ",
            "aufgaben": "\n".join(a_zeilen) or "- [ ] ",
            "offene_punkte": self._zeilen(d.get("offene_punkte")),
            "naechster_termin": (iso(naechster) or "") + (f", {d.get('naechste_zeit').strip()}"
                                                          if naechster and (d.get("naechste_zeit") or "").strip() else ""),
            "naechste_themen": (d.get("naechste_themen") or "").strip(),
        })
        datei = self._unique(ziel / f"Projektprotokoll_{datum.isoformat()}_{safe_name(projekt, True)}.md")
        datei.write_text(text, encoding="utf-8")
        with self.db() as con:
            self._index_file(con, datei, dt.date.today())
        if als_tasks:  # jede Aufgabe direkt als Task (Planer, Heute, Teammitglieder)
            link = f"Aus dem [[{self.rel(datei)[:-3]}|Projektprotokoll vom {dmy(datum.isoformat())}]]"
            fallback = naechster or (datum + dt.timedelta(days=7))
            inhalt = datei.read_text(encoding="utf-8")
            for (text_, wer, frist), zeile in zip([a for a in aufgaben if (a[0] or "").strip()], a_zeilen):
                f = parse_date(frist) or fallback
                verantwortlich = ", ".join(link_name(x) for x in self._personen_links(wer).split(", ") if x)
                task = self.task_anlegen(text_.strip(), iso(min(dt.date.today(), f)), iso(f), projekt, "mittel",
                                         verantwortlich, link, unterordner=ziel.relative_to(root).as_posix(),
                                         extra={"protokoll": f"[[{self.rel(datei)[:-3]}]]"})
                if parse_date(frist) is None:  # Fälligkeit, die der Task bekommen hat, auch im Protokoll zeigen
                    zeile_neu = zeile + f" 📅 {iso(f)}"
                else:
                    zeile_neu = zeile
                zeile_neu += f" ([[{self.rel(task)[:-3]}|Task]])"
                inhalt = inhalt.replace(zeile + "\n", zeile_neu + "\n", 1)
            datei.write_text(inhalt, encoding="utf-8")
            with self.db() as con:
                self._index_file(con, datei, dt.date.today())
        return datei

    def protokolle(self, projekt: str = "") -> list[dict]:
        out = [e for e in self.eintraege("projektprotokoll") if not projekt or e["projekt"] == projekt]
        for e in out:
            e["datum"] = iso(parse_date(e.get("datum"))) or e["geaendert"][:10]
        out.sort(key=lambda e: (e["datum"], e["geaendert"]), reverse=True)
        return out

    def _team_mails(self, namen: list[str]) -> list[str]:
        team = self.eintraege("person")
        mails = []
        for n in namen:
            n_l = n.strip().lower()
            for p in team:
                if n_l in {(p["titel"] or "").lower(), (p.get("kuerzel") or "").lower()} and p.get("email"):
                    if p["email"] not in mails:
                        mails.append(p["email"])
        return mails

    def protokoll_mail(self, rel: str) -> dict:
        """Betreff, Empfänger (aus Teammitgliedern), HTML- und Textfassung eines Protokolls."""
        p = self.abs_in_vault(rel)
        md = p.read_text(encoding="utf-8")
        fm, body = parse_frontmatter(md)
        projekt = link_name(fm.get("projekt")) or self._projekt_aus_pfad(rel)
        datum = iso(parse_date(fm.get("datum"))) or ""
        namen = []
        for feld in ("Teilnehmende", "Moderation"):
            m = re.search(rf"\*\*{feld}:\*\*(.*)", body)
            if m:
                namen += [link_name(x) for x in re.findall(r"\[\[[^\]]+\]\]", m.group(1))]
        # In der Mail Daten als TT.MM.JJJJ (im Markdown bleiben sie JJJJ-MM-TT, wie Obsidian/Dataview es braucht)
        md_mail = re.sub(r"\b(\d{4})-(\d{2})-(\d{2})\b", r"\3.\2.\1", md)
        md_mail = md_mail.replace("📅 ", "fällig ")
        md_mail = re.sub(r" \(\[\[[^\]]+\|Task\]\]\)", "", md_mail)  # interne Task-Links nicht in die Mail
        return {"betreff": f"Projektprotokoll: {projekt} – {dmy(datum)}" if datum else f"Projektprotokoll: {projekt}",
                "an": self._team_mails(namen), "namen": namen, "html": md_zu_html(md_mail), "text": md_zu_text(md_mail),
                "datei": p.stem}

    def protokoll_eml(self, rel: str) -> tuple[str, bytes]:
        """E-Mail-Entwurf (.eml) für Outlook: öffnet sich als neue, bearbeitbare Nachricht."""
        from email.message import EmailMessage
        m = self.protokoll_mail(rel)
        msg = EmailMessage()
        msg["Subject"] = m["betreff"]
        if m["an"]:
            msg["To"] = ", ".join(m["an"])
        msg["X-Unsent"] = "1"           # Outlook: als Entwurf öffnen, nicht als empfangene Mail
        msg.set_content(m["text"])
        msg.add_alternative(f"<html><body>{m['html']}</body></html>", subtype="html")
        return f"{m['datei']}.eml", msg.as_bytes()

    # --- Projektplan (Projektaufgaben) ------------------------------------------
    PLAN_AUFGABEN = "## 📋 Aufgabenliste"
    PLAN_NOTIZEN = "## 📝 Notizen & Entscheidungen"
    _PLAN_ITEM = re.compile(r"^- \[([ xX])\] (.*)$")
    _PLAN_SUB = re.compile(r"^(\s+)[-*] \[([ xX])\] (.*)$")
    _PLAN_TASK = re.compile(r"\s*\(\[\[([^\]|]+)\|Task\]\]\)")
    _PLAN_STATUS = re.compile(r"^\*\*Status:\*\*\s*(.*?)\s*$")

    @staticmethod
    def _status_aus_text(text: str) -> str:
        """Task-Status aus dem Inhalt einer Task-Datei (gleiche Regeln wie beim Sync)."""
        fm, body = parse_frontmatter(text)
        raw = (fm.get("status") or "").lower().strip()
        checks = CHECK_RE.findall(body)
        if raw in ERLEDIGT_WERTE or (fm.get("erledigt") or "").lower() in ERLEDIGT_WERTE:
            return "erledigt"
        if not raw and checks and all(c.lower() == "x" for c in checks):
            return "erledigt"
        return raw if raw in TASK_STATUS else "offen"

    def _plan_ordner(self, projekt: str) -> Path:
        root = self.ordner("projekt_ordner") / safe_name(projekt)
        if not projekt or not root.is_dir():
            raise ValueError("Bitte ein Projekt wählen.")
        ziel = root / ((self.cfg.get("plan_ordner") or "06_Projekte").strip("/\\"))
        if not ziel.is_dir():
            ziel.mkdir(parents=True)
            self._readme_schreiben(ziel, projekt, self.projekt_struktur().get(ziel.name, ""))
        return ziel

    def _plan_zeile(self, text: str, wer: str, frist: str, prio: str, task: Path | None, erledigt=False) -> str:
        z = f"- [{'x' if erledigt else ' '}] {text.strip()}"
        if (wer or "").strip():
            z += " " + " ".join("@" + w for w in self._personen_links(wer).split(", "))
        if (prio or "").lower() in ("hoch", "⏫"):
            z += " ⏫"
        if parse_date(frist):
            z += f" 📅 {iso(parse_date(frist))}"
        if task is not None:
            z += f" ([[{self.rel(task)[:-3]}|Task]])"
        return z

    def _plan_task(self, plan: Path, projekt: str, phase: str, text: str, wer: str, frist: str,
                   prio: str, unterpunkte: list[str]) -> Path:
        f = parse_date(frist)
        verantwortlich = ", ".join(link_name(x) for x in self._personen_links(wer).split(", ") if x)
        start = min(dt.date.today(), f) if f else dt.date.today()
        return self.task_anlegen(
            text.strip(), iso(start), iso(f) if f else "", projekt,
            "hoch" if (prio or "").lower() in ("hoch", "⏫") else "mittel", verantwortlich,
            f"Aus dem Projektplan [[{self.rel(plan)[:-3]}|{plan.stem.replace('_', ' ')}]], {phase}",
            "\n".join(unterpunkte), ordner=plan.parent,
            extra={"plan": f"[[{self.rel(plan)[:-3]}]]", "phase": phase})

    @staticmethod
    def _unterpunkte(s: str) -> list[str]:
        return [u.strip().lstrip("-*• ").strip() for u in re.split(r"[;\n]", s or "") if u.strip().lstrip("-*• ")]

    def plan_anlegen(self, d: dict, phasen: list[dict]) -> Path:
        """phasen: [{"name": str, "aufgaben": [(text, wer, frist, prio, unterpunkte)]}]"""
        self.ensure_basics()
        projekt = (d.get("projekt") or "").strip()
        titel = (d.get("titel") or "").strip() or projekt
        ziel = self._plan_ordner(projekt)
        datei = self._unique(ziel / f"Projektplan_{safe_name(titel, True)}.md")
        uebersicht = f"_Projekt_{safe_name(projekt, True)}"
        deadline = iso(parse_date(d.get("deadline"))) or ""
        datei.write_text("", encoding="utf-8")  # Pfad reservieren, damit Tasks darauf verlinken können
        zeilen = ["---", "type: projektplan", f'titel: {fm_value(titel)}',
                  f'projekt: "[[{uebersicht}|{projekt}]]"', f"status: {d.get('status') or 'aktiv'}",
                  f"deadline: {deadline}", "tags:", "  - projekt", "  - projektplan", "---", "",
                  f"# Projekt: {titel}", "", "## 🎯 Ziel & Kontext",
                  (d.get("ziel") or "").strip() or "Kurze Beschreibung, was am Ende fertig sein muss.", "",
                  self.PLAN_AUFGABEN]
        nr = 0
        for ph in phasen:
            name = (ph.get("name") or "").strip()
            aufgaben = [a for a in ph.get("aufgaben", []) if (a[0] or "").strip()]
            if not name and not aufgaben:
                continue
            nr += 1
            kopf = f"Phase {nr}: {name or 'Ohne Namen'}"
            zeilen += ["", f"### {kopf}", "**Status:** offen"]
            for text, wer, frist, prio, unter in aufgaben:
                up = self._unterpunkte(unter)
                frist = frist if parse_date(frist) else deadline   # ohne Datum: bis zur Deadline
                task = self._plan_task(datei, projekt, kopf, text, wer, frist, prio, up)
                zeilen.append(self._plan_zeile(text, wer, frist, prio, task))
                zeilen += [f"  - [ ] {u}" for u in up]
        if nr == 0:
            zeilen += ["", "### Phase 1: Vorbereitung", "**Status:** offen", "- [ ] "]
        notizen = [n.strip() for n in (d.get("notizen") or "").splitlines() if n.strip()]
        zeilen += ["", self.PLAN_NOTIZEN] + [f"- {dmy(iso(dt.date.today()))}: {n}" for n in notizen] + (
            [] if notizen else ["- "])
        datei.write_text("\n".join(zeilen) + "\n", encoding="utf-8")
        self.plan_abgleichen(self.rel(datei))
        return datei

    def plan_lesen(self, rel: str) -> dict:
        p = self.abs_in_vault(rel)
        text = p.read_text(encoding="utf-8")
        fm, _ = parse_frontmatter(text)
        zeilen = text.split("\n")
        phasen, aktiv, ziel, notizen, abschnitt = [], False, [], [], ""
        status_db = {}
        with self.db() as con:
            for r in con.execute("SELECT pfad, status, verantwortlich, ende, prioritaet FROM tasks WHERE aktiv=1"):
                status_db[r["pfad"]] = dict(r)
        for i, z in enumerate(zeilen):
            if z.startswith("## "):
                abschnitt = z
                aktiv = z.strip() == self.PLAN_AUFGABEN
                continue
            if abschnitt.startswith("## 🎯") and z.strip():
                ziel.append(z)
            if abschnitt.strip() == self.PLAN_NOTIZEN and z.strip() not in ("", "-"):
                notizen.append(z.lstrip("- ").strip())
            if not aktiv:
                continue
            if z.startswith("### "):
                phasen.append({"name": z[4:].strip(), "zeile": i, "status": "offen", "status_zeile": None,
                               "aufgaben": [], "ende_zeile": i})
                continue
            if not phasen:
                continue
            ph = phasen[-1]
            m = self._PLAN_STATUS.match(z)
            if m:
                ph["status"] = m.group(1).strip().lower().replace(" ", "_") or "offen"
                ph["status_zeile"] = i
                ph["ende_zeile"] = i
                continue
            m = self._PLAN_ITEM.match(z)
            if m:
                rest = m.group(2)
                tm = self._PLAN_TASK.search(rest)
                task = (tm.group(1) + ".md") if tm else ""
                rest_ohne = self._PLAN_TASK.sub("", rest)
                due = re.search(r"📅\s*(\d{4}-\d{2}-\d{2})", rest_ohne)
                wer = [link_name(x) for x in re.findall(r"@(\[\[[^\]]+\]\])", rest_ohne)]
                titel = re.sub(r"@\[\[[^\]]+\]\]|⏫|🔼|🔽|📅\s*\d{4}-\d{2}-\d{2}", "", rest_ohne).strip()
                info = status_db.get(task, {})
                ph["aufgaben"].append({
                    "zeile": i, "titel": titel or "(leer)", "erledigt": m.group(1).lower() == "x",
                    "task": task if task in status_db else "", "task_fehlt": bool(task) and task not in status_db,
                    "status": info.get("status") or ("erledigt" if m.group(1).lower() == "x" else "offen"),
                    "wer": ", ".join(wer) or info.get("verantwortlich", ""), "ende": iso(parse_date(due.group(1))) if due else info.get("ende"),
                    "prio": "hoch" if "⏫" in rest_ohne else (info.get("prioritaet") or "mittel"),
                    "link": self.obsidian_link(task) if task else "", "unter": []})
                ph["ende_zeile"] = i
                continue
            m = self._PLAN_SUB.match(z)
            if m and ph["aufgaben"]:
                ph["aufgaben"][-1]["unter"].append({"text": m.group(3), "erledigt": m.group(2).lower() == "x"})
                ph["ende_zeile"] = i
        heute = dt.date.today()
        alle = [a for ph in phasen for a in ph["aufgaben"]]
        for ph in phasen:
            ph["n"] = len([a for a in ph["aufgaben"] if a["titel"] != "(leer)"])
            ph["fertig"] = sum(a["status"] == "erledigt" for a in ph["aufgaben"] if a["titel"] != "(leer)")
            for a in ph["aufgaben"]:
                e = parse_date(a["ende"])
                a["ueberfaellig"] = bool(e and e < heute and a["status"] != "erledigt")
        n = sum(ph["n"] for ph in phasen)
        fertig = sum(ph["fertig"] for ph in phasen)
        deadline = iso(parse_date(fm.get("deadline")))
        return {"pfad": rel, "link": self.obsidian_link(rel), "titel": fm.get("titel") or p.stem.replace("_", " "),
                "projekt": link_name(fm.get("projekt")) or self._projekt_aus_pfad(rel),
                "status": fm.get("status") or "aktiv", "deadline": deadline,
                "deadline_in": (parse_date(deadline) - heute).days if deadline else None,
                "ziel": "\n".join(ziel), "notizen": notizen, "phasen": phasen, "n": n, "fertig": fertig,
                "ueberfaellig": sum(a["ueberfaellig"] for a in alle)}

    def plaene(self, projekt: str = "") -> list[dict]:
        out = []
        for e in self.eintraege("projektplan"):
            if projekt and e["projekt"] != projekt:
                continue
            try:
                out.append(self.plan_lesen(e["pfad"]))
            except (OSError, ValueError):
                continue
        out.sort(key=lambda x: (x["status"] != "aktiv", x["deadline"] or "9999", x["titel"].lower()))
        return out

    def _abgleich_merken(self, con, schluessel: str) -> int | None:
        r = con.execute("SELECT erledigt FROM plan_abgleich WHERE schluessel=?", (schluessel,)).fetchone()
        return None if r is None else r[0]

    def plan_abgleichen(self, rel: str) -> bool:
        """Häkchen im Plan <-> Status der verlinkten Tasks abgleichen (in beide Richtungen).
        Wer sich seit dem letzten Abgleich geändert hat, gewinnt; ändern sich beide, gewinnt der Task.
        Danach den Phasen-Status nachführen. Rückgabe: True, wenn der Plan geändert wurde."""
        p = self.abs_in_vault(rel)
        zeilen = p.read_text(encoding="utf-8").split("\n")
        geaendert = False
        task_schreiben: dict[Path, str] = {}
        with self.db() as con:
            con.execute("CREATE TABLE IF NOT EXISTS plan_abgleich (schluessel TEXT PRIMARY KEY, erledigt INTEGER)")
            aktuelle_task = None
            for i, z in enumerate(zeilen):
                m = self._PLAN_ITEM.match(z)
                if m:
                    aktuelle_task = None
                    tm = self._PLAN_TASK.search(m.group(2))
                    if not tm:
                        continue
                    tp = self.vault / (tm.group(1) + ".md")
                    if not tp.is_file():
                        continue
                    aktuelle_task = tp
                    ttext = task_schreiben.get(tp) or tp.read_text(encoding="utf-8")
                    plan_x = m.group(1).lower() == "x"
                    task_x = self._status_aus_text(ttext) == "erledigt"
                    key = self.rel(tp)
                    alt = self._abgleich_merken(con, key)
                    if plan_x != task_x:
                        if alt is not None and bool(alt) == task_x:   # nur der Plan hat sich geändert
                            neu_status = "erledigt" if plan_x else "offen"
                            task_schreiben[tp] = set_frontmatter(ttext, {
                                "status": neu_status, "erledigt_am": iso(dt.date.today()) if plan_x else ""})
                            task_x = plan_x
                        else:                                         # Task gewinnt
                            zeilen[i] = f"- [{'x' if task_x else ' '}] " + m.group(2)
                            geaendert = True
                    con.execute("INSERT OR REPLACE INTO plan_abgleich VALUES (?,?)", (key, int(task_x)))
                    continue
                m = self._PLAN_SUB.match(z)
                if m and aktuelle_task is not None:
                    tp = aktuelle_task
                    ttext = task_schreiben.get(tp) or tp.read_text(encoding="utf-8")
                    text_u = m.group(3).strip()
                    tm2 = re.search(rf"(?m)^(\s*[-*] \[)([ xX])(\] {re.escape(text_u)}\s*)$", ttext)
                    if not tm2:
                        continue
                    plan_x, task_x = m.group(2).lower() == "x", tm2.group(2).lower() == "x"
                    key = f"{self.rel(tp)}::{text_u}"
                    alt = self._abgleich_merken(con, key)
                    if plan_x != task_x:
                        if alt is not None and bool(alt) == task_x:
                            task_schreiben[tp] = ttext[:tm2.start(2)] + ("x" if plan_x else " ") + ttext[tm2.end(2):]
                            task_x = plan_x
                        else:
                            zeilen[i] = f"{m.group(1)}- [{'x' if task_x else ' '}] {m.group(3)}"
                            geaendert = True
                    con.execute("INSERT OR REPLACE INTO plan_abgleich VALUES (?,?)", (key, int(task_x)))
                elif not z.startswith((" ", "\t")):
                    aktuelle_task = None
        for tp, ttext in task_schreiben.items():
            tp.write_text(ttext, encoding="utf-8")
            with self.db() as con:
                self._index_file(con, tp, dt.date.today())
        # Phasen-Status nachführen
        aktiv, idx_status, items = False, None, []

        def phase_abschliessen():
            nonlocal geaendert
            if idx_status is None or not items:
                return
            alt = self._PLAN_STATUS.match(zeilen[idx_status]).group(1).strip().lower().replace(" ", "_")
            erledigt = sum(items)
            neu = alt
            if erledigt == len(items):
                neu = "erledigt"
            elif alt == "erledigt":
                neu = "in_arbeit"
            elif erledigt and alt == "offen":
                neu = "in_arbeit"
            if neu != alt:
                zeilen[idx_status] = f"**Status:** {neu}"
                geaendert = True
        for i, z in enumerate(zeilen):
            if z.startswith("## "):
                if aktiv:
                    phase_abschliessen()
                aktiv = z.strip() == self.PLAN_AUFGABEN
                idx_status, items = None, []
                continue
            if not aktiv:
                continue
            if z.startswith("### "):
                phase_abschliessen()
                idx_status, items = None, []
            elif self._PLAN_STATUS.match(z):
                idx_status = i
            else:
                m = self._PLAN_ITEM.match(z)
                if m and m.group(2).strip():
                    items.append(m.group(1).lower() == "x")
        if aktiv:
            phase_abschliessen()
        if geaendert:
            p.write_text("\n".join(zeilen), encoding="utf-8")
        with self.db() as con:
            self._index_file(con, p, dt.date.today())
        return geaendert

    def plaene_abgleichen(self) -> int:
        n = 0
        for e in self.eintraege("projektplan"):
            try:
                n += self.plan_abgleichen(e["pfad"])
            except Exception as exc:  # ein defekter Plan soll den Sync nicht stoppen
                print(f"[WARN] Plan {e['pfad']}: {exc}", file=sys.stderr)
        return n

    def _plan_aufgabenliste_ende(self, zeilen: list[str]) -> int:
        """Index der Zeile, vor der neue Phasen eingefügt werden (Ende des Abschnitts Aufgabenliste)."""
        drin = False
        for i, z in enumerate(zeilen):
            if z.strip() == self.PLAN_AUFGABEN:
                drin = True
                continue
            if drin and z.startswith("## "):
                j = i
                while j > 0 and not zeilen[j - 1].strip():
                    j -= 1
                return j
        return len(zeilen)

    def plan_aufgabe(self, rel: str, phase_zeile: int, text: str, wer: str = "", frist: str = "",
                     prio: str = "", unterpunkte: str = "") -> Path:
        if not (text or "").strip():
            raise ValueError("Bitte eine Aufgabe eingeben.")
        plan = self.plan_lesen(rel)
        ph = next((x for x in plan["phasen"] if x["zeile"] == int(phase_zeile)), None)
        if not ph:
            raise ValueError("Phase nicht gefunden. Bitte Seite neu laden.")
        p = self.abs_in_vault(rel)
        up = self._unterpunkte(unterpunkte)
        frist = frist if parse_date(frist) else (plan["deadline"] or "")
        task = self._plan_task(p, plan["projekt"], ph["name"], text, wer, frist, prio, up)
        zeilen = p.read_text(encoding="utf-8").split("\n")
        leer = [a["zeile"] for a in ph["aufgaben"] if a["titel"] == "(leer)"]
        neu = [self._plan_zeile(text, wer, frist, prio, task)] + [f"  - [ ] {u}" for u in up]
        if leer:  # Platzhalter "- [ ] " ersetzen
            zeilen[leer[0]:leer[0] + 1] = neu
        else:
            zeilen[ph["ende_zeile"] + 1:ph["ende_zeile"] + 1] = neu
        p.write_text("\n".join(zeilen), encoding="utf-8")
        self.plan_abgleichen(rel)
        return task

    def plan_phase(self, rel: str, name: str) -> None:
        name = (name or "").strip()
        if not name:
            raise ValueError("Bitte einen Namen für die Phase eingeben.")
        p = self.abs_in_vault(rel)
        zeilen = p.read_text(encoding="utf-8").split("\n")
        nr = len(self.plan_lesen(rel)["phasen"]) + 1
        pos = self._plan_aufgabenliste_ende(zeilen)
        zeilen[pos:pos] = ["", f"### Phase {nr}: {name}", "**Status:** offen"]
        p.write_text("\n".join(zeilen), encoding="utf-8")
        with self.db() as con:
            self._index_file(con, p, dt.date.today())

    def plan_phase_status(self, rel: str, phase_zeile: int, status: str) -> None:
        if status not in TASK_STATUS:
            raise ValueError("Ungültiger Status")
        p = self.abs_in_vault(rel)
        zeilen = p.read_text(encoding="utf-8").split("\n")
        ph = next((x for x in self.plan_lesen(rel)["phasen"] if x["zeile"] == int(phase_zeile)), None)
        if not ph:
            raise ValueError("Phase nicht gefunden. Bitte Seite neu laden.")
        if ph["status_zeile"] is not None:
            zeilen[ph["status_zeile"]] = f"**Status:** {status}"
        else:
            zeilen.insert(ph["zeile"] + 1, f"**Status:** {status}")
        p.write_text("\n".join(zeilen), encoding="utf-8")
        with self.db() as con:
            self._index_file(con, p, dt.date.today())

    def plan_notiz(self, rel: str, text: str) -> None:
        text = (text or "").strip()
        if not text:
            raise ValueError("Bitte einen Text eingeben.")
        p = self.abs_in_vault(rel)
        zeilen = p.read_text(encoding="utf-8").rstrip("\n").split("\n")
        if self.PLAN_NOTIZEN not in [z.strip() for z in zeilen]:
            zeilen += ["", self.PLAN_NOTIZEN]
        i = [z.strip() for z in zeilen].index(self.PLAN_NOTIZEN)
        j = i + 1
        while j < len(zeilen) and not zeilen[j].startswith("## "):
            j += 1
        while j > i + 1 and not zeilen[j - 1].strip():
            j -= 1
        if j - 1 > i and zeilen[j - 1].strip() == "-":  # leeren Platzhalter ersetzen
            j -= 1
            del zeilen[j]
        zeilen.insert(j, f"- {dmy(iso(dt.date.today()))}: {text}")
        p.write_text("\n".join(zeilen) + "\n", encoding="utf-8")
        with self.db() as con:
            self._index_file(con, p, dt.date.today())

    STATUS_TEXT = {"offen": "offen", "in_arbeit": "in Arbeit", "wartend": "wartend", "erledigt": "erledigt"}

    def plan_mail(self, rel: str, phase_zeile: int | None = None) -> dict:
        """Statusbericht eines Projektplans (gesamt oder eine Phase) als E-Mail-Inhalt."""
        plan = self.plan_lesen(rel)
        phasen = plan["phasen"] if phase_zeile is None else [
            x for x in plan["phasen"] if x["zeile"] == int(phase_zeile)]
        if not phasen:
            raise ValueError("Phase nicht gefunden.")
        heute = dt.date.today()
        einzel = phase_zeile is not None
        kopf = phasen[0]["name"] if einzel else "Statusbericht"
        md = [f"# {kopf}: {plan['titel']} – {dmy(iso(heute))}", "",
              f"**Projekt:** {plan['projekt']}  ",
              f"**Projektstatus:** {plan['status']}" + (f" · **Deadline:** {dmy(plan['deadline'])}" if plan['deadline'] else "") + "  "]
        if einzel:
            ph = phasen[0]
            md.append(f"**Phasen-Status:** {self.STATUS_TEXT.get(ph['status'], ph['status'])} "
                      f"({ph['fertig']} von {ph['n']} Aufgaben erledigt)  ")
        else:
            md.append(f"**Fortschritt:** {plan['fertig']} von {plan['n']} Aufgaben erledigt"
                      + (f" · {plan['ueberfaellig']} überfällig" if plan['ueberfaellig'] else "") + "  ")
            md += ["", "## Übersicht der Phasen"]
            md += [f"- **{ph['name']}** – {self.STATUS_TEXT.get(ph['status'], ph['status'])} ({ph['fertig']}/{ph['n']})"
                   for ph in phasen]
        namen = []
        for ph in phasen:
            md += ["", f"## {ph['name']} – {self.STATUS_TEXT.get(ph['status'], ph['status'])}"]
            for a in ph["aufgaben"]:
                if a["titel"] == "(leer)":
                    continue
                z = f"- [{'x' if a['status'] == 'erledigt' else ' '}] {a['titel']}"
                if a["status"] in ("in_arbeit", "wartend"):
                    z += f" *({self.STATUS_TEXT[a['status']]})*"
                if a["wer"]:
                    z += f" – {a['wer']}"
                    namen += [n.strip() for n in a["wer"].split(",")]
                if a["ende"]:
                    z += f", fällig {dmy(a['ende'])}" + (" **(überfällig)**" if a["ueberfaellig"] else "")
                md.append(z)
                md += [f"  - [{'x' if u['erledigt'] else ' '}] {u['text']}" for u in a["unter"]]
            if not ph["n"]:
                md.append("- Noch keine Aufgaben.")
        if not einzel and plan["notizen"]:
            md += ["", "## Notizen & Entscheidungen"] + [f"- {n}" for n in plan["notizen"]]
        text = "\n".join(md) + "\n"
        betreff = (f"{phasen[0]['name']} – {plan['titel']} ({self.STATUS_TEXT.get(phasen[0]['status'], '')})"
                   if einzel else f"Statusbericht: {plan['titel']} – {dmy(iso(heute))}")
        datei = f"Status_{safe_name(plan['titel'], True)}" + (f"_{safe_name(phasen[0]['name'], True)}" if einzel else "")
        return {"betreff": betreff, "an": self._team_mails(list(dict.fromkeys(namen))), "namen": namen,
                "html": md_zu_html(text), "text": md_zu_text(text), "datei": datei}

    def plan_eml(self, rel: str, phase_zeile: int | None = None) -> tuple[str, bytes]:
        from email.message import EmailMessage
        m = self.plan_mail(rel, phase_zeile)
        msg = EmailMessage()
        msg["Subject"] = m["betreff"]
        if m["an"]:
            msg["To"] = ", ".join(m["an"])
        msg["X-Unsent"] = "1"
        msg.set_content(m["text"])
        msg.add_alternative(f"<html><body>{m['html']}</body></html>", subtype="html")
        return f"{m['datei']}.eml", msg.as_bytes()

    # --- Jour Fixe -------------------------------------------------------------
    @staticmethod
    def _jf_naechster(datum: dt.date, turnus: str) -> dt.date | None:
        tage = JF_TURNUS.get(turnus)
        if tage is None:
            return None
        if tage:
            return datum + dt.timedelta(days=tage)
        m = datum.month % 12 + 1
        j = datum.year + (datum.month == 12)
        for tag in (datum.day, 30, 29, 28):
            try:
                return dt.date(j, m, tag)
            except ValueError:
                continue
        return None

    def jf_pendenzen(self, serie: str = "", alle: bool = False) -> list[dict]:
        """Tasks mit Feld 'jourfixe' (= Pendenzen), offen zuerst nach Fälligkeit."""
        g = self.tasks()
        gruppen = ("ueberfaellig", "heute", "geplant", "ohne_datum") + (("erledigt",) if alle else ())
        out = [t for k in gruppen for t in g[k] if t.get("jourfixe")]
        if serie:
            out = [t for t in out if t["jourfixe"].lower() == serie.lower()]
        out.sort(key=lambda t: (t["status"] == "erledigt", t["ende"] or "9999", t["titel"].lower()))
        return out

    def jf_sitzungen(self, serie: str = "") -> list[dict]:
        s = [e for e in self.eintraege("jourfixe") if not serie or (e.get("serie") or "").lower() == serie.lower()]
        s.sort(key=lambda e: iso(parse_date(e.get("datum"))) or "", reverse=True)
        return s

    def jf_serien(self) -> list[dict]:
        """Jour-Fixe-Serien = Unterordner im Jour-Fixe-Ordner, ergänzt um Serien aus Sitzungen/Pendenzen."""
        heute = dt.date.today()
        namen: dict[str, str] = {}
        jdir = self.ordner("jourfixe_ordner")
        if jdir.is_dir():
            for d in jdir.iterdir():
                if d.is_dir() and not d.name.startswith("."):
                    namen.setdefault(d.name.lower(), d.name)
        sitzungen = self.jf_sitzungen()
        pendenzen = self.jf_pendenzen()
        for x in [e.get("serie") for e in sitzungen] + [t["jourfixe"] for t in pendenzen]:
            if x:
                namen.setdefault(x.lower(), x)
        out = []
        for key, name in sorted(namen.items()):
            ss = [e for e in sitzungen if (e.get("serie") or "").lower() == key]
            pp = [t for t in pendenzen if t["jourfixe"].lower() == key]
            letzte = ss[0] if ss else None
            naechster = parse_date(letzte.get("naechster_termin")) if letzte else None
            out.append({"name": name, "sitzungen": len(ss), "letzte": letzte,
                        "naechster": iso(naechster), "naechster_in": (naechster - heute).days if naechster else None,
                        "offen": len(pp), "ueberfaellig": sum(t["kategorie"] == "ueberfaellig" for t in pp),
                        "projekt": (letzte or {}).get("projekt", ""),
                        "teilnehmer": (letzte or {}).get("teilnehmer", ""),
                        "moderation": (letzte or {}).get("moderation", "")})
        return out

    def jf_sitzung_anlegen(self, d: dict) -> Path:
        serie = safe_name(d.get("serie") or "")
        if not serie:
            raise ValueError("Bitte eine Serie wählen oder einen neuen Namen eingeben.")
        datum = parse_date(d.get("datum")) or dt.date.today()
        naechster = parse_date(d.get("naechster_termin")) or self._jf_naechster(datum, d.get("turnus") or "")
        offen = self.jf_pendenzen(serie)
        if offen:
            zeilen = ["| Pendenz | Verantwortlich | Fällig | Status |", "|---|---|---|---|"]
            zeilen += [f"| [[{t['pfad'][:-3]}\\|{t['titel']}]] | {t['verantwortlich'] or ''} | {dmy(t['ende'])} | "
                       f"{t['status'].replace('_', ' ')} |" for t in offen]
            pendenzen = "\n".join(zeilen)
        else:
            pendenzen = "Keine offenen Pendenzen."
        agenda = "\n".join(f"{i}. {z.strip()}" for i, z in enumerate(
            (z for z in (d.get("agenda") or "").splitlines() if z.strip()), 1)) or "1. Pendenzen durchgehen\n2. "
        datei = self._eintrag_datei("jourfixe_ordner", serie, f"JF_{datum.isoformat()}_{safe_name(serie, True)}")
        return self._eintrag_schreiben("jourfixe", datei, {
            "title": f"Jour Fixe {serie} {dmy(datum.isoformat())}", "serie": serie, "datum": datum.isoformat(),
            "projekt": d.get("projekt"), "moderation": d.get("moderation"), "teilnehmer": d.get("teilnehmer"),
            "naechster_termin": iso(naechster) or "", "agenda": agenda, "pendenzen": pendenzen})

    def jf_pendenz_anlegen(self, d: dict) -> Path:
        serie = safe_name(d.get("serie") or "")
        if not serie:
            raise ValueError("Bitte eine Jour-Fixe-Serie wählen.")
        projekt = d.get("projekt") or ""
        if projekt and not (self.ordner("projekt_ordner") / safe_name(projekt)).is_dir():
            projekt = ""
        sitzung = self.jf_sitzungen(serie)
        extra = {"jourfixe": serie}
        beschreibung = d.get("beschreibung") or ""
        if sitzung:
            extra["jf_sitzung"] = f"[[{sitzung[0]['pfad'][:-3]}]]"
            beschreibung = (beschreibung + "\n\n" if beschreibung else "") + \
                f"Aus dem Jour Fixe: [[{sitzung[0]['pfad'][:-3]}|{sitzung[0]['titel']}]]"
        heute = dt.date.today()
        ende = parse_date(d.get("ende"))
        if not ende:  # ohne Fälligkeit: bis zum nächsten Termin der Serie
            serie_info = next((s for s in self.jf_serien() if s["name"].lower() == serie.lower()), None)
            ende = parse_date(serie_info["naechster"]) if serie_info and serie_info["naechster"] else heute
        start = parse_date(d.get("start")) or min(heute, ende)
        return self.task_anlegen(d.get("titel", ""), iso(start), iso(ende), projekt,
                                 d.get("prioritaet") or "mittel", d.get("verantwortlich", ""), beschreibung,
                                 d.get("checkliste", ""), ordner=self.ordner("jourfixe_ordner") / serie / "Pendenzen",
                                 extra=extra)

    # --- Suche ---------------------------------------------------------------
    def suche(self, q: str, typ: str = "", limit: int = 100) -> list[dict]:
        woerter = [w for w in q.split() if w]
        if not woerter:
            return []
        sql = "SELECT pfad, titel, typ, projekt, inhalt FROM notizen WHERE 1=1"
        args: list = []
        for w in woerter:
            sql += " AND (titel LIKE ? OR inhalt LIKE ? OR pfad LIKE ?)"
            args += [f"%{w}%"] * 3
        if typ:
            sql += " AND typ=?"
            args.append(typ)
        sql += " ORDER BY geaendert DESC LIMIT ?"
        args.append(limit)
        out = []
        with self.db() as con:
            for r in con.execute(sql, args):
                inhalt = r["inhalt"] or ""
                pos = inhalt.lower().find(woerter[0].lower())
                snippet = inhalt[max(0, pos - 80): pos + 160] if pos >= 0 else inhalt[:200]
                treffer_titel = sum(w.lower() in (r["titel"] or "").lower() for w in woerter)
                out.append({"pfad": r["pfad"], "titel": r["titel"], "typ": r["typ"],
                            "projekt": r["projekt"], "snippet": snippet.replace("\n", " "),
                            "link": self.obsidian_link(r["pfad"]), "score": treffer_titel})
        out.sort(key=lambda x: -x["score"])
        return out

    # --- Sync ------------------------------------------------------------------
    def _iter_md(self):
        skip = {".obsidian", ".trash", ".git", "node_modules"}
        for p in self.vault.rglob("*.md"):
            if any(part in skip for part in p.relative_to(self.vault).parts):
                continue
            yield p

    def _projekt_aus_pfad(self, rel: str) -> str:
        po = self.cfg.get("projekt_ordner") or ""
        parts = rel.split("/")
        if po:
            if len(parts) > 2 and parts[0] == po:
                return parts[1]
        elif len(parts) > 1 and (self.vault / parts[0] / "01_Vertraege_und_SLA").is_dir():
            return parts[0]
        return ""

    def _index_file(self, con: sqlite3.Connection, p: Path, heute: dt.date):
        rel = self.rel(p)
        text = p.read_text(encoding="utf-8", errors="replace")
        fm, body = parse_frontmatter(text)
        typ = (fm.get("typ") or fm.get("type") or "").lower()
        name_l = p.name.lower()
        vorlagen = self.cfg.get("vorlagen_ordner") or "_Vorlagen"
        ist_vorlage = rel.startswith(vorlagen + "/")
        projekt = link_name(fm.get("projekt")) or self._projekt_aus_pfad(rel)
        titel = fm.get("titel") or fm.get("title") or p.stem
        geaendert = dt.datetime.fromtimestamp(p.stat().st_mtime).isoformat(timespec="seconds")
        if ist_vorlage:
            typ = "vorlage"

        if not ist_vorlage and (name_l.startswith("task_") or typ == "task"):
            typ = "task"
            if not fm.get("titel") and name_l.startswith("task_"):
                titel = p.stem[5:].replace("_", " ")
            checks = CHECK_RE.findall(body)
            total, done = len(checks), sum(c.lower() == "x" for c in checks)
            raw = (fm.get("status") or "").lower().strip()
            if raw in ERLEDIGT_WERTE or (fm.get("erledigt") or "").lower() in ERLEDIGT_WERTE:
                status = "erledigt"
            elif not raw and total and total == done:
                status = "erledigt"
            elif raw in TASK_STATUS:
                status = raw
            else:
                status = "offen"
            erledigt_am = iso(parse_date(fm.get("erledigt_am"))) or (heute.isoformat() if status == "erledigt" else None)
            con.execute("""
                INSERT INTO tasks (pfad, titel, projekt, start, ende, status, prioritaet, verantwortlich,
                                   checks_total, checks_done, erledigt_am, geaendert, aktiv, jourfixe)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,1,?)
                ON CONFLICT(pfad) DO UPDATE SET
                    titel=excluded.titel, projekt=excluded.projekt, start=excluded.start, ende=excluded.ende,
                    status=excluded.status, prioritaet=excluded.prioritaet, verantwortlich=excluded.verantwortlich,
                    checks_total=excluded.checks_total, checks_done=excluded.checks_done,
                    erledigt_am=CASE WHEN excluded.status='erledigt'
                                     THEN COALESCE(tasks.erledigt_am, excluded.erledigt_am) ELSE NULL END,
                    geaendert=excluded.geaendert, aktiv=1, jourfixe=excluded.jourfixe
            """, (rel, titel, projekt, iso(parse_date(fm.get("start"))), iso(parse_date(fm.get("ende") or fm.get("end"))),
                  status, (fm.get("prioritaet") or "mittel").lower(), fm.get("verantwortlich", ""),
                  total, done, erledigt_am, geaendert, (fm.get("jourfixe") or "").strip()))
        elif not ist_vorlage and (name_l.startswith("lcm_") or typ == "lcm"):
            typ = "lcm"
            if not fm.get("titel") and name_l.startswith("lcm_"):
                titel = p.stem[4:].replace("_", " ")
            con.execute("""
                INSERT OR REPLACE INTO lcm (pfad, titel, kategorie, hersteller, produkt, version, projekt, standort,
                    inbetriebnahme, end_of_support, end_of_life, status, verantwortlich, aktiv)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,1)
            """, (rel, titel, fm.get("kategorie", ""), fm.get("hersteller", ""), fm.get("produkt", ""),
                  fm.get("version", ""), projekt, fm.get("standort", ""),
                  iso(parse_date(fm.get("inbetriebnahme"))), iso(parse_date(fm.get("end_of_support"))),
                  iso(parse_date(fm.get("end_of_life"))), fm.get("status", ""), fm.get("verantwortlich", "")))

        wiki = self.cfg.get("wiki_ordner") or "Wiki"
        kategorie = fm.get("kategorie", "")
        if not typ and rel.startswith(wiki + "/"):
            typ = "wiki"
        if not typ and not name_l.startswith(("readme_", "_")):
            for key, t in (("devops_ordner", "devops"), ("ideen_ordner", "idee"), ("team_ordner", "person"),
                           ("jourfixe_ordner", "jourfixe")):
                o = self.cfg.get(key) or ""
                if o and rel.startswith(o + "/"):
                    typ = t
                    break
        if typ == "wiki" and not kategorie:
            parts = rel.split("/")
            kategorie = "/".join(parts[1:-1]) if len(parts) > 2 else ""
        con.execute("INSERT OR REPLACE INTO notizen (pfad, titel, typ, projekt, tags, kategorie, geaendert, inhalt, meta) "
                    "VALUES (?,?,?,?,?,?,?,?,?)",
                    (rel, titel, typ or "notiz", projekt, fm.get("tags", ""), kategorie, geaendert, body,
                     json.dumps(fm, ensure_ascii=False)))

    def _tagesuebersicht(self, con: sqlite3.Connection, heute: dt.date):
        d = heute.isoformat()
        con.execute("DELETE FROM tagesuebersicht WHERE datum=?", (d,))
        for r in con.execute("SELECT * FROM tasks WHERE aktiv=1").fetchall():
            t = dict(r)
            kat = task_kategorie(t, heute)
            if kat == "erledigt" and t["erledigt_am"] != d:
                continue
            con.execute("INSERT INTO tagesuebersicht VALUES (?,?,?,?,?,?,?,?)",
                        (d, t["pfad"], t["titel"], t["projekt"], kat, t["status"], t["ende"], t["prioritaet"]))

    def _planer_notiz(self, heute: dt.date):
        g = self.tasks(heute)
        n_tage = int(self.cfg.get("demnaechst_tage", 7))
        bald = [t for t in g["geplant"] if parse_date(t["start"]) <= heute + dt.timedelta(days=n_tage)]
        gestern = (heute - dt.timedelta(days=1)).isoformat()
        erledigt = [t for t in g["erledigt"] if (t["erledigt_am"] or "") >= gestern]
        lcm = [e for e in self.lcm_eintraege(heute) if e["ampel"]["farbe"] in ("rot", "orange")]

        def zeile(t):
            teile = [f"- [[{t['pfad'][:-3]}|{t['titel']}]]"]
            if t["projekt"]:
                teile.append(f"· {t['projekt']}")
            if t["ende"]:
                teile.append(f"· bis {dmy(t['ende'])}")
            if (t["prioritaet"] or "") == "hoch":
                teile.append("· ❗hoch")
            if t["checks_total"]:
                teile.append(f"· {t['checks_done']}/{t['checks_total']} ✓")
            return " ".join(teile)

        wt = ["Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag"][heute.weekday()]
        z = ["---", "typ: planer", f"datum: {heute.isoformat()}",
             f"aktualisiert: {dt.datetime.now().isoformat(timespec='minutes')}", "---",
             f"# Tagesübersicht {wt}, {heute.strftime('%d.%m.%Y')}",
             "> Automatisch erzeugt vom Obsidian-Agent – Änderungen in dieser Datei werden überschrieben.", ""]
        for titel, liste in ((f"🎯 Heute ({len(g['heute'])})", g["heute"]),
                             (f"⚠️ Überfällig ({len(g['ueberfaellig'])})", g["ueberfaellig"]),
                             (f"📅 Demnächst – nächste {n_tage} Tage ({len(bald)})", bald),
                             (f"✅ Seit gestern erledigt ({len(erledigt)})", erledigt)):
            z += [f"## {titel}"] + ([zeile(t) for t in liste] or ["- –"]) + [""]
        if lcm:
            z += [f"## ♻️ LifeCycle-Warnungen ({len(lcm)})"]
            z += [f"- [[{e['pfad'][:-3]}|{e['titel']}]] · {e['ampel']['text']}" for e in lcm] + [""]
        inhalt = "\n".join(z)
        pdir = self.ordner("planer_ordner")
        (pdir / "Archiv").mkdir(parents=True, exist_ok=True)
        (pdir / "Heute.md").write_text(inhalt, encoding="utf-8")
        (pdir / "Archiv" / f"Tagesuebersicht_{heute.isoformat()}.md").write_text(inhalt, encoding="utf-8")

    def sync(self, art: str = "manuell") -> dict:
        with self._lock:
            t0 = time.time()
            heute = dt.date.today()
            self.ensure_basics()
            dateien = 0
            with self.db() as con:
                con.execute("UPDATE tasks SET aktiv=0")
                con.execute("UPDATE lcm SET aktiv=0")
                con.execute("DELETE FROM notizen")
                for p in self._iter_md():
                    try:
                        self._index_file(con, p, heute)
                        dateien += 1
                    except Exception as exc:  # einzelne defekte Datei soll den Sync nicht stoppen
                        print(f"[WARN] {p}: {exc}", file=sys.stderr)
                con.execute("DELETE FROM tasks WHERE aktiv=0")
                con.execute("DELETE FROM lcm WHERE aktiv=0")
                self._tagesuebersicht(con, heute)
            self.plaene_abgleichen()
            self._planer_notiz(heute)
            self._wiki_index()
            g = self.tasks(heute)
            stats = {"zeitpunkt": dt.datetime.now().isoformat(timespec="seconds"), "art": art,
                     "dateien": dateien,
                     "tasks_offen": sum(len(g[k]) for k in ("heute", "ueberfaellig", "geplant", "ohne_datum")),
                     "tasks_heute": len(g["heute"]), "tasks_erledigt": len(g["erledigt"]),
                     "lcm": len(self.lcm_eintraege(heute)),
                     "dauer_ms": int((time.time() - t0) * 1000)}
            with self.db() as con:
                con.execute("INSERT INTO sync_log (zeitpunkt, art, dateien, tasks_offen, tasks_heute, "
                            "tasks_erledigt, lcm, dauer_ms) VALUES (:zeitpunkt,:art,:dateien,:tasks_offen,"
                            ":tasks_heute,:tasks_erledigt,:lcm,:dauer_ms)", stats)
            return stats

    def sync_log(self, limit: int = 20) -> list[dict]:
        with self.db() as con:
            return [dict(r) for r in con.execute(
                "SELECT * FROM sync_log ORDER BY id DESC LIMIT ?", (limit,))]

    def letzter_sync(self) -> dict | None:
        log = self.sync_log(1)
        return log[0] if log else None

    # --- Zeitplan ----------------------------------------------------------------
    def geplanter_sync_faellig(self, jetzt: dt.datetime | None = None) -> bool:
        jetzt = jetzt or dt.datetime.now()
        h, m = (int(x) for x in str(self.cfg.get("sync_zeit", "04:00")).split(":"))
        slot = jetzt.replace(hour=h, minute=m, second=0, microsecond=0)
        if jetzt < slot:
            slot -= dt.timedelta(days=1)
        with self.db() as con:
            last = con.execute("SELECT MAX(zeitpunkt) FROM sync_log WHERE art='geplant'").fetchone()[0]
        return last is None or dt.datetime.fromisoformat(last) < slot

    def starte_scheduler(self):
        def loop():
            while True:
                try:
                    if self.vault_ok() and self.geplanter_sync_faellig():
                        s = self.sync("geplant")
                        print(f"[Agent] Geplanter Sync: {s['tasks_heute']} heute, {s['tasks_offen']} offen")
                except Exception as exc:
                    print(f"[Agent] Sync-Fehler: {exc}", file=sys.stderr)
                time.sleep(60)
        threading.Thread(target=loop, daemon=True, name="agent-scheduler").start()


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def main(argv=None):
    ap = argparse.ArgumentParser(description="Obsidian-Agent")
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("sync", help="Vault einlesen und Tagesübersicht schreiben")
    s.add_argument("--geplant", action="store_true", help="als geplanten Tageslauf protokollieren")
    sub.add_parser("heute", help="heutige Tasks anzeigen")
    p = sub.add_parser("projekt", help="neues Projekt anlegen")
    p.add_argument("name")
    a = ap.parse_args(argv)

    agent = Agent()
    if a.cmd == "sync":
        st = agent.sync("geplant" if a.geplant else "manuell")
        print(f"Sync OK – {st['dateien']} Dateien, {st['tasks_heute']} Tasks heute, "
              f"{st['tasks_offen']} offen, {st['dauer_ms']} ms")
    elif a.cmd == "heute":
        g = agent.tasks()
        for titel, k in (("HEUTE", "heute"), ("ÜBERFÄLLIG", "ueberfaellig")):
            print(f"\n== {titel} ({len(g[k])}) ==")
            for t in g[k]:
                print(f"  [{t['prioritaet'][:1].upper()}] {t['titel']}  ({t['projekt'] or '-'}, bis {dmy(t['ende'])})")
    elif a.cmd == "projekt":
        print(f"Projekt angelegt: {agent.projekt_anlegen(a.name)}")


if __name__ == "__main__":
    main()
