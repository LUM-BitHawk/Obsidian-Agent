@echo off
REM Obsidian-Agent oeffnen (Windows).
REM Laeuft der Agent schon, wird nur der Browser geoeffnet. Sonst wird er im
REM Hintergrund gestartet. Ist er noch nicht installiert, startet die Installation.
cd /d "%~dp0"

if not exist ".venv\Scripts\pythonw.exe" (
    call "%~dp0installieren.bat"
    exit /b
)

set PORT=
for /f %%p in ('powershell -NoProfile -Command "try{(Get-Content config.json -Raw | ConvertFrom-Json).port}catch{}"') do set PORT=%%p
if "%PORT%"=="" set PORT=5055

netstat -ano | findstr ":%PORT% " | findstr LISTENING >nul
if not errorlevel 1 goto offen

echo Obsidian-Agent wird im Hintergrund gestartet ...
schtasks /Run /TN "Obsidian-Agent Weboberflaeche" >nul 2>&1
if errorlevel 1 start "" ".venv\Scripts\pythonw.exe" "%~dp0hintergrund.pyw"
for /l %%i in (1,1,20) do (
    netstat -ano | findstr ":%PORT% " | findstr LISTENING >nul && goto offen
    timeout /t 1 /nobreak >nul
)
echo.
echo Der Agent startet nicht. Er wird jetzt im Vordergrund gestartet,
echo damit die Fehlermeldung sichtbar ist:
echo.
".venv\Scripts\python.exe" app.py
pause
exit /b 1

:offen
start "" http://127.0.0.1:%PORT%
