﻿# ======================================================================
#  Obsidian-Agent – Installation für Windows
#  Wird von installieren.bat aufgerufen. Richtet in einem Durchgang ein:
#   1. Python-Umgebung (.venv) und Flask
#   2. Vault-Pfad (Ordner-Dialog, falls noch keiner gesetzt ist)
#   3. Aufgabe "Obsidian-Agent Weboberflaeche": startet die Oberfläche bei
#      jeder Anmeldung im Hintergrund (ohne Fenster, auch im Akkubetrieb)
#   4. Aufgabe "Obsidian-Agent Tages-Sync": täglicher Sync (holt verpasste
#      Läufe nach, wenn der PC zur Sync-Zeit aus war)
#  Mehrfach ausführbar: bestehende Einträge werden aktualisiert, nichts geht verloren.
#  Keine Administratorrechte nötig.
# ======================================================================
$ErrorActionPreference = 'Continue'
$Dir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Dir

$TaskGui  = 'Obsidian-Agent Weboberflaeche'
$TaskSync = 'Obsidian-Agent Tages-Sync'
$Startup  = [Environment]::GetFolderPath('Startup')
$Lnk      = Join-Path $Startup 'Obsidian-Agent.lnk'
$OldVbs   = Join-Path $Startup 'Obsidian-Agent.vbs'
$LogFile  = Join-Path $env:LOCALAPPDATA 'obsidian-agent\gui.log'
$VenvPy   = Join-Path $Dir '.venv\Scripts\python.exe'
$VenvPyw  = Join-Path $Dir '.venv\Scripts\pythonw.exe'
$Starter  = Join-Path $Dir 'hintergrund.pyw'

function Ok($m)   { Write-Host "[OK] $m" -ForegroundColor Green }
function Warn($m) { Write-Host "[!!] $m" -ForegroundColor Yellow }
function Info($m) { Write-Host "...  $m" }
function Fail($m) { Write-Host "[FEHLER] $m" -ForegroundColor Red; Read-Host 'Enter zum Beenden'; exit 1 }
function Lauscht($p) { [bool](Get-NetTCPConnection -LocalPort $p -State Listen -ErrorAction SilentlyContinue) }

Write-Host ''
Write-Host '=== Obsidian-Agent – Installation (Windows) ===' -ForegroundColor Cyan
Write-Host "Programmordner: $Dir"
Write-Host ''

# --- 1. Python und Python-Umgebung ----------------------------------------------
if (-not (Test-Path $VenvPy)) {
    $py = $null
    foreach ($kandidat in @('py -3', 'python')) {
        $teile = $kandidat.Split(' ')
        $exe = $teile[0]; $arg = @($teile | Select-Object -Skip 1)
        if (-not (Get-Command $exe -ErrorAction SilentlyContinue)) { continue }
        $v = & $exe @arg -c 'import sys; print(sys.version_info >= (3, 10))' 2>$null
        if ($v -eq 'True') { $py = @{ exe = $exe; arg = $arg }; break }
    }
    if (-not $py) {
        Start-Process 'https://www.python.org/downloads/windows/'
        Fail 'Python 3.10 oder neuer wurde nicht gefunden. Bitte installieren (Haekchen "Add python.exe to PATH") und installieren.bat erneut starten.'
    }
    Info 'Python-Umgebung wird eingerichtet'
    & $py.exe @($py.arg) -m venv .venv
    if (-not (Test-Path $VenvPy)) { Fail 'Python-Umgebung (.venv) konnte nicht angelegt werden.' }
}
& $VenvPy -m pip install -q --upgrade pip 2>$null | Out-Null
& $VenvPy -m pip install -q -r requirements.txt
if ($LASTEXITCODE -ne 0) { Fail 'Installation von Flask fehlgeschlagen (Internet oder Proxy pruefen).' }
Ok "Python-Umgebung bereit ($(& $VenvPy --version))"

# --- 2. Vault ---------------------------------------------------------------------
$vaultOk = & $VenvPy -c "import agent, os; c = agent.load_config(); print(os.path.isdir(os.path.expanduser(c['vault_path'])))"
if ($vaultOk -ne 'True') {
    Info 'Bitte im Dialog deinen Obsidian-Vault-Ordner waehlen (ggf. hinter diesem Fenster)'
    Add-Type -AssemblyName System.Windows.Forms
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description = 'Bitte deinen Obsidian-Vault-Ordner waehlen'
    $dlg.ShowNewFolderButton = $false
    if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        & $VenvPy -c "import agent, sys; c = agent.load_config(); c['vault_path'] = sys.argv[1]; agent.save_config(c)" $dlg.SelectedPath
        Ok "Vault: $($dlg.SelectedPath)"
    } else {
        Warn 'Kein Vault gewaehlt - du kannst den Pfad spaeter unter Einstellungen setzen.'
    }
} else {
    Ok "Vault: $(& $VenvPy -c "import agent; print(agent.load_config()['vault_path'])")"
}
& $VenvPy agent.py sync

$Port     = [int](& $VenvPy -c "import agent; print(agent.load_config().get('port', 5055))")
$SyncZeit = (& $VenvPy -c "import agent; print(agent.load_config().get('sync_zeit', '04:00'))")

# --- 3. Geplante Aufgaben -------------------------------------------------------------
$User = "$env:USERDOMAIN\$env:USERNAME"
$Settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
    -StartWhenAvailable -MultipleInstances IgnoreNew -ExecutionTimeLimit ([TimeSpan]::Zero) `
    -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1)
$Principal = New-ScheduledTaskPrincipal -UserId $User -LogonType Interactive -RunLevel Limited

# 3a. Weboberfläche bei der Anmeldung im Hintergrund
$guiArt = $null
try {
    $act = New-ScheduledTaskAction -Execute $VenvPyw -Argument "`"$Starter`"" -WorkingDirectory $Dir
    $trg = New-ScheduledTaskTrigger -AtLogOn -User $User
    Register-ScheduledTask -TaskName $TaskGui -Action $act -Trigger $trg -Settings $Settings `
        -Principal $Principal -Description 'Startet die Obsidian-Agent-Weboberflaeche im Hintergrund.' `
        -Force -ErrorAction Stop | Out-Null
    if (Test-Path $Lnk) { Remove-Item $Lnk -Force }
    $guiArt = 'task'
    Ok "Aufgabe '$TaskGui' eingerichtet (Start bei jeder Anmeldung)"
} catch {
    # Fallback ohne Aufgabenplanung: Verknüpfung im persönlichen Autostart-Ordner
    $ws = New-Object -ComObject WScript.Shell
    $s = $ws.CreateShortcut($Lnk)
    $s.TargetPath = $VenvPyw
    $s.Arguments = "`"$Starter`""
    $s.WorkingDirectory = $Dir
    $s.Description = 'Obsidian-Agent im Hintergrund'
    $s.Save()
    $guiArt = 'lnk'
    Warn "Aufgabenplanung nicht erlaubt ($($_.Exception.Message.Trim()))"
    Ok "Stattdessen Autostart-Verknuepfung angelegt: $Lnk"
}
if (Test-Path $OldVbs) { Remove-Item $OldVbs -Force; Ok 'Alten Autostart (Obsidian-Agent.vbs) entfernt' }

# 3b. Täglicher Sync
try {
    $h, $m = $SyncZeit.Split(':')
    $act = New-ScheduledTaskAction -Execute $VenvPyw -Argument "`"$Dir\agent.py`" sync --geplant" -WorkingDirectory $Dir
    $trg = New-ScheduledTaskTrigger -Daily -At ([datetime]::Today.AddHours([int]$h).AddMinutes([int]$m))
    Register-ScheduledTask -TaskName $TaskSync -Action $act -Trigger $trg -Settings $Settings `
        -Principal $Principal -Description 'Taeglicher Sync des Obsidian-Agent (Tagesuebersicht).' `
        -Force -ErrorAction Stop | Out-Null
    Ok "Aufgabe '$TaskSync' eingerichtet (taeglich $SyncZeit, verpasste Laeufe werden nachgeholt)"
} catch {
    Warn "Taeglicher Sync konnte nicht eingerichtet werden: $($_.Exception.Message.Trim())"
    Warn 'Die Tagesuebersicht wird dann nur aktualisiert, solange die Weboberflaeche laeuft.'
}

# --- 4. Jetzt starten und prüfen ---------------------------------------------------------
if (Lauscht $Port) {
    Ok "Agent laeuft bereits auf Port $Port"
    Warn 'Laeuft er noch in einem start.bat-Fenster, dieses schliessen und installieren.bat erneut starten.'
} else {
    Info 'Agent wird im Hintergrund gestartet'
    if ($guiArt -eq 'task') { Start-ScheduledTask -TaskName $TaskGui }
    else { Start-Process -FilePath $VenvPyw -ArgumentList "`"$Starter`"" -WorkingDirectory $Dir }
    for ($i = 0; $i -lt 20 -and -not (Lauscht $Port); $i++) { Start-Sleep -Milliseconds 500 }
}
Write-Host ''
if (Lauscht $Port) {
    Ok "Fertig! Weboberflaeche: http://127.0.0.1:$Port"
    Write-Host '     Sie startet ab jetzt nach jedem Neustart automatisch im Hintergrund.'
    Start-Process "http://127.0.0.1:$Port"
} else {
    Warn "Der Agent antwortet nicht auf Port $Port."
    if (Test-Path $LogFile) { Write-Host '     Letzte Zeilen aus dem Protokoll:'; Get-Content $LogFile -Tail 8 }
    Write-Host "     Protokoll: $LogFile"
}
Write-Host ''
Read-Host 'Enter zum Schliessen'
