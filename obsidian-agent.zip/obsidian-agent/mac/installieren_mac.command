#!/bin/bash
# ======================================================================
#  Obsidian-Agent – Installation für macOS (Doppelklick im Finder)
#  - prüft Python, legt die Python-Umgebung (.venv) an
#  - fragt nach dem Obsidian-Vault (Ordner-Auswahl)
#  - richtet den täglichen Sync per launchd ein (läuft nach dem Aufwachen nach)
#  - optional: Agent beim Anmelden automatisch im Hintergrund starten
# ======================================================================
cd "$(dirname "$0")/.." || exit 1
DIR="$(pwd)"
LA="$HOME/Library/LaunchAgents"
LOGDIR="$HOME/Library/Logs/obsidian-agent"
UIDN="$(id -u)"
SYNC_LABEL="ch.obsidian-agent.sync"
GUI_LABEL="ch.obsidian-agent.gui"

echo ""
echo "=== Obsidian-Agent – Installation (macOS) ==="
echo "Programmordner: $DIR"
echo ""

# Quarantäne-Flag (aus dem Internet geladen) entfernen, damit die Skripte laufen
xattr -dr com.apple.quarantine "$DIR" 2>/dev/null
chmod +x "$DIR"/mac/*.command "$DIR"/start.sh 2>/dev/null

# --- 1. Python suchen (mind. 3.9) ------------------------------------------
PY=""
for c in python3.13 python3.12 python3.11 python3.10 python3 /usr/local/bin/python3 /opt/homebrew/bin/python3; do
  if command -v "$c" >/dev/null 2>&1 && "$c" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' 2>/dev/null; then
    PY="$(command -v "$c")"; break
  fi
done
if [ -z "$PY" ]; then
  echo "❌ Python 3.9 oder neuer wurde nicht gefunden."
  echo "   Variante A: Installer von https://www.python.org/downloads/macos/"
  echo "   Variante B: im Terminal  brew install python"
  echo "   Danach dieses Skript erneut starten."
  open "https://www.python.org/downloads/macos/"
  read -r -p "Enter zum Beenden …"; exit 1
fi
echo "✅ Python: $PY ($("$PY" --version 2>&1))"

# --- 2. Python-Umgebung ---------------------------------------------------------
if [ ! -x .venv/bin/python ]; then
  echo "… Python-Umgebung wird eingerichtet"
  "$PY" -m venv .venv || { echo "❌ venv konnte nicht angelegt werden"; read -r; exit 1; }
fi
.venv/bin/python -m pip install -q --upgrade pip >/dev/null 2>&1
.venv/bin/python -m pip install -q -r requirements.txt || { echo "❌ Installation von Flask fehlgeschlagen (Internet?)"; read -r; exit 1; }
VPY="$DIR/.venv/bin/python"
echo "✅ Abhängigkeiten installiert"

# --- 3. Vault wählen ------------------------------------------------------------------
if ! "$VPY" -c "import agent,os,sys; c=agent.load_config(); sys.exit(0 if os.path.isdir(os.path.expanduser(c['vault_path'])) else 1)" 2>/dev/null; then
  echo "… Bitte im Dialog deinen Obsidian-Vault-Ordner wählen"
  VAULT=$(osascript -e 'POSIX path of (choose folder with prompt "Bitte deinen Obsidian-Vault-Ordner wählen:")' 2>/dev/null)
  if [ -z "$VAULT" ]; then
    echo "⚠️  Kein Vault gewählt – du kannst den Pfad später unter Einstellungen setzen."
  else
    "$VPY" -c "import agent,sys; c=agent.load_config(); c['vault_path']=sys.argv[1].rstrip('/'); agent.save_config(c)" "$VAULT"
    echo "✅ Vault: $VAULT"
  fi
else
  echo "✅ Vault aus config.json: $("$VPY" -c "import agent; print(agent.load_config()['vault_path'])")"
fi

# --- 4. Erster Sync (im Terminal → macOS fragt ggf. nach Ordnerzugriff) -----------------
"$VPY" agent.py sync 2>&1 | tail -1

# --- 5. LaunchAgents schreiben ------------------------------------------------------------
mkdir -p "$LA" "$LOGDIR"
read -r -p "Agent bei jeder Anmeldung automatisch im Hintergrund starten? (j/n) " AUTO
"$VPY" - "$DIR" "$LA" "$LOGDIR" "$SYNC_LABEL" "$GUI_LABEL" "${AUTO:-n}" <<'PYEOF'
import plistlib, sys, os
sys.path.insert(0, sys.argv[1])
import agent
d, la, logdir, sync_label, gui_label, auto = sys.argv[1:7]
py = os.path.join(d, ".venv", "bin", "python")
h, m = (int(x) for x in agent.load_config().get("sync_zeit", "04:00").split(":"))
sync = {
    "Label": sync_label,
    "ProgramArguments": [py, os.path.join(d, "agent.py"), "sync", "--geplant"],
    "WorkingDirectory": d,
    "StartCalendarInterval": {"Hour": h, "Minute": m},
    "StandardOutPath": os.path.join(logdir, "sync.log"),
    "StandardErrorPath": os.path.join(logdir, "sync.log"),
}
with open(os.path.join(la, sync_label + ".plist"), "wb") as f:
    plistlib.dump(sync, f)
gui_path = os.path.join(la, gui_label + ".plist")
if auto.lower().startswith(("j", "y")):
    gui = {
        "Label": gui_label,
        "ProgramArguments": [py, os.path.join(d, "app.py")],
        "WorkingDirectory": d,
        "RunAtLoad": True,
        "EnvironmentVariables": {"OBSIDIAN_AGENT_NO_BROWSER": "1"},
        "StandardOutPath": os.path.join(logdir, "gui.log"),
        "StandardErrorPath": os.path.join(logdir, "gui.log"),
    }
    with open(gui_path, "wb") as f:
        plistlib.dump(gui, f)
elif os.path.exists(gui_path):
    os.remove(gui_path)
print(f"✅ Täglicher Sync um {h:02d}:{m:02d} eingerichtet")
PYEOF

lade() {  # $1 = Label
  local plist="$LA/$1.plist"
  launchctl bootout "gui/$UIDN/$1" 2>/dev/null || launchctl unload "$plist" 2>/dev/null
  [ -f "$plist" ] && { launchctl bootstrap "gui/$UIDN" "$plist" 2>/dev/null || launchctl load -w "$plist"; }
}
lade "$SYNC_LABEL"
lade "$GUI_LABEL"
[ -f "$LA/$GUI_LABEL.plist" ] && echo "✅ Autostart beim Anmelden aktiv"

# --- 6. Hintergrund-Sync testen (Ordnerrechte von macOS) ---------------------------------
: > "$LOGDIR/sync.log"
launchctl kickstart "gui/$UIDN/$SYNC_LABEL" 2>/dev/null
sleep 4
if grep -qiE "Operation not permitted|PermissionError" "$LOGDIR/sync.log"; then
  REAL=$("$VPY" -c "import os,sys; print(os.path.realpath(sys.executable))")
  echo ""
  echo "⚠️  macOS blockiert den Hintergrund-Zugriff auf deinen Vault (typisch für"
  echo "   Dokumente, Schreibtisch oder iCloud Drive). So erlaubst du ihn:"
  echo "   Systemeinstellungen → Datenschutz & Sicherheit → Festplattenvollzugriff → „+“"
  echo "   und diese Datei hinzufügen (Cmd+Shift+G zum Einfügen des Pfads):"
  echo "   $REAL"
  open "x-apple.systempreferences:com.apple.preference.security?Privacy_AllFiles" 2>/dev/null
elif grep -q "Traceback\|Error" "$LOGDIR/sync.log"; then
  echo "⚠️  Der Hintergrund-Sync meldet einen Fehler:"
  tail -3 "$LOGDIR/sync.log"
  echo "   (Vault-Pfad unter Einstellungen prüfen, danach Installation erneut starten.)"
else
  echo "✅ Hintergrund-Sync funktioniert"
fi

echo ""
echo "Fertig! Starten mit Doppelklick auf  mac/starten_mac.command"
echo "Protokolle: $LOGDIR"
read -r -p "Agent jetzt öffnen? (j/n) " JETZT
if [[ "$JETZT" == [jJyY]* ]]; then
  exec "$DIR/mac/starten_mac.command"
fi
