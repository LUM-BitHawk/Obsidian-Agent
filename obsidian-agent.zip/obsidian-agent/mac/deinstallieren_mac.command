#!/bin/bash
# ======================================================================
#  Obsidian-Agent – Deinstallation (macOS)
#  - beendet den laufenden Agent, entfernt Autostart + 04:00-Sync (launchd)
#  - sichert config.json und planer.db auf den Schreibtisch
#  - entfernt die Python-Umgebung und optional den Programmordner
#  Der Obsidian-Vault wird NICHT verändert.
# ======================================================================
cd "$(dirname "$0")/.." || exit 1
DIR="$(pwd)"
LA="$HOME/Library/LaunchAgents"
UIDN="$(id -u)"

echo ""
echo "=== Obsidian-Agent deinstallieren ==="
echo "Programmordner: $DIR"
echo "(Dein Obsidian-Vault bleibt unverändert.)"
read -r -p "Fortfahren? (j/n) " OK
[[ "$OK" == [jJyY]* ]] || exit 0

PORT=$(grep -o '"port": *[0-9]*' config.json 2>/dev/null | grep -o '[0-9]*$')
PORT=${PORT:-5055}

# --- 1. launchd-Jobs entfernen --------------------------------------------------
for L in ch.obsidian-agent.gui ch.obsidian-agent.sync; do
  if [ -f "$LA/$L.plist" ]; then
    launchctl bootout "gui/$UIDN/$L" 2>/dev/null || launchctl unload "$LA/$L.plist" 2>/dev/null
    rm -f "$LA/$L.plist"
    echo "✅ $L entfernt"
  fi
done

# --- 2. Laufenden Agent beenden --------------------------------------------------
PIDS=$(lsof -ti tcp:"$PORT" -sTCP:LISTEN 2>/dev/null)
[ -n "$PIDS" ] && kill $PIDS 2>/dev/null && echo "✅ Laufender Agent beendet"

# --- 3. Backup -------------------------------------------------------------------------
BACKUP="$HOME/Desktop/obsidian-agent-backup_$(date +%Y-%m-%d_%H%M)"
mkdir -p "$BACKUP"
for f in config.json planer.db; do [ -f "$f" ] && cp "$f" "$BACKUP/"; done
echo "✅ Backup: $BACKUP"

# --- 4. Python-Umgebung, Protokolle ------------------------------------------------
rm -rf .venv __pycache__ && echo "✅ Python-Umgebung entfernt"
read -r -p "Protokolle (~/Library/Logs/obsidian-agent) löschen? (j/n) " LG
[[ "$LG" == [jJyY]* ]] && rm -rf "$HOME/Library/Logs/obsidian-agent"

# --- 5. Programmordner -------------------------------------------------------------------
read -r -p "Programmordner $DIR komplett löschen? (j/n) " DEL
if [[ "$DEL" == [jJyY]* ]]; then
  cd "$HOME" && rm -rf "$DIR" && echo "✅ Programmordner gelöscht"
else
  echo ""
  echo "Umzug: Programm am neuen Ort entpacken, config.json und planer.db aus dem"
  echo "Backup hineinkopieren und mac/installieren_mac.command ausführen."
fi
echo ""
echo "Deinstallation abgeschlossen."
read -r -p "Enter zum Schliessen …"
