@echo off
REM Obsidian-Agent - Installation (Windows). Mehrfach ausfuehrbar, keine Adminrechte noetig.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0installieren.ps1"
