@echo off
setlocal
REM ======================================================================
REM  Obsidian-Agent - Deinstallation (Windows)
REM  - beendet den laufenden Agent
REM  - entfernt die geplanten Aufgaben (Weboberflaeche und Tages-Sync)
REM  - sichert config.json und planer.db auf den Desktop
REM  - entfernt die Python-Umgebung (.venv) und optional den Programmordner
REM  Der Obsidian-Vault wird NICHT veraendert.
REM ======================================================================
cd /d "%~dp0"
set "DIR=%~dp0"
set "DIR=%DIR:~0,-1%"

echo.
echo  Obsidian-Agent deinstallieren
echo  Programmordner: %DIR%
echo  (Dein Obsidian-Vault bleibt unveraendert.)
echo.
choice /C JN /M "Fortfahren"
if errorlevel 2 exit /b 0

REM --- 1. Laufenden Agent beenden ------------------------------------------
set PORT=
for /f %%p in ('powershell -NoProfile -Command "try{(Get-Content config.json -Raw | ConvertFrom-Json).port}catch{}"') do set PORT=%%p
if "%PORT%"=="" set PORT=5055
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":%PORT% " ^| findstr LISTENING') do (
    taskkill /PID %%a /F >nul 2>&1 && echo [OK] Laufender Agent beendet (PID %%a^)
)

REM --- 2. Geplante Aufgaben und Autostart entfernen ----------------------------------
for %%t in ("Obsidian-Agent Weboberflaeche" "Obsidian-Agent Tages-Sync") do (
    schtasks /Query /TN %%t >nul 2>&1 && schtasks /Delete /TN %%t /F >nul && echo [OK] Aufgabe %%~t entfernt
)
for /f "usebackq delims=" %%s in (`powershell -NoProfile -Command "[Environment]::GetFolderPath('Startup')"`) do set "STARTUP=%%s"
if exist "%STARTUP%\Obsidian-Agent.lnk" del "%STARTUP%\Obsidian-Agent.lnk" && echo [OK] Autostart-Verknuepfung entfernt
if exist "%STARTUP%\Obsidian-Agent.vbs" del "%STARTUP%\Obsidian-Agent.vbs" && echo [OK] Alter Autostart entfernt
if exist "%LOCALAPPDATA%\obsidian-agent" rd /s /q "%LOCALAPPDATA%\obsidian-agent"

REM --- 3. Backup -----------------------------------------------------------------
for /f "usebackq delims=" %%d in (`powershell -NoProfile -Command "[Environment]::GetFolderPath('Desktop') + '\obsidian-agent-backup_' + (Get-Date -Format 'yyyy-MM-dd_HHmm')"`) do set "BACKUP=%%d"
mkdir "%BACKUP%" >nul 2>&1
if exist config.json copy /Y config.json "%BACKUP%\" >nul
if exist planer.db copy /Y planer.db "%BACKUP%\" >nul
echo [OK] Backup: %BACKUP%

REM --- 4. Python-Umgebung entfernen ------------------------------------------------
if exist ".venv" rd /s /q ".venv" && echo [OK] Python-Umgebung (.venv) entfernt
if exist "__pycache__" rd /s /q "__pycache__"

REM --- 5. Programmordner loeschen? ----------------------------------------------
echo.
choice /C JN /M "Programmordner %DIR% komplett loeschen"
if errorlevel 2 goto ende
echo.
echo Deinstallation abgeschlossen. Backup liegt auf dem Desktop:
echo %BACKUP%
echo Der Programmordner wird nach dem Schliessen dieses Fensters geloescht.
pause
cd /d "%TEMP%"
start "" /min cmd /c "timeout /t 3 /nobreak >nul & rd /s /q "%DIR%""
exit

:ende
echo.
echo Deinstallation abgeschlossen. Die Programmdateien sind noch vorhanden.
echo Backup liegt auf dem Desktop: %BACKUP%
echo.
echo Umzug: Programm am neuen Ort entpacken, config.json und planer.db aus dem
echo Backup hineinkopieren und installieren.bat ausfuehren.
pause
